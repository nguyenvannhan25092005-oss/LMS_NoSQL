# LMS quản lý môn học và điểm số

Thư mục bàn giao gồm:

- `source/`: mã nguồn React, Express, cấu hình và kiểm thử.
- `database/`: bản xuất dữ liệu MongoDB hiện tại, gồm dữ liệu và thông tin index. Định dạng MongoDB Extended JSON giữ kiểu ObjectId, ngày và số.

## Chạy trên máy hiện tại

MongoDB Server đang dùng cổng 27017. Mở terminal trong `source`:

```powershell
npm.cmd ci
npm.cmd run db:check
npm.cmd start
```

Mở http://127.0.0.1:3000/dashboard. Nếu cổng 3000 đang có bản chạy, dùng bản đó hoặc dừng đúng tiến trình cũ trước khi chạy lại.

## Chạy trên máy khác

1. Cài Node.js 22.12+ và MongoDB Server; mở dịch vụ MongoDB.
2. Vào `source`, chạy `npm.cmd ci`.
3. Nếu cần cấu hình khác, copy `.env.example` thành `.env`, sửa MONGODB_URI và DB_NAME.
4. Chọn database đích trống và chạy `npm.cmd run db:import` để nhập dữ liệu từ thư mục `database` bên cạnh `source`.
5. Chạy `npm.cmd start`, mở http://127.0.0.1:3000/dashboard.

Lệnh nhập từ chối database đã có dữ liệu để tránh ghi đè. Máy hiện tại đã có dữ liệu nên không cần nhập lại. Chọn DB_NAME khác nếu muốn thử bản xuất độc lập.

## Xem database bằng Compass

Kết nối `mongodb://127.0.0.1:27017`, mở database `lms_tuan1_module2`. Có thể nhập từng file courses.json/students.json vào collection tương ứng bằng chức năng Import JSON của Compass. Cách nhập qua lệnh db:import khôi phục cả index và kiểm tra database trống.

Website đọc dữ liệu từ MongoDB qua API; không tự nạp dữ liệu mẫu khi khởi động. Các file trong source/mongo/seed chỉ dùng khi chủ động chạy npm run seed.

## Các trang chính

- `/dashboard`: tổng quan dữ liệu.
- `/courses`: thêm, xem, sửa, chuyển môn vào thùng rác và khôi phục.
- `/grades`: tìm kiếm, lọc, phân trang; nhập điểm bằng popup ngay trên danh sách; sửa và xóa điểm trên các trang riêng.
- `/students`: tra cứu sinh viên và hồ sơ điểm.

Module chỉ phụ trách môn học và điểm. Hồ sơ, tài khoản và đăng nhập do module tài khoản/sinh viên của nhóm tích hợp.

