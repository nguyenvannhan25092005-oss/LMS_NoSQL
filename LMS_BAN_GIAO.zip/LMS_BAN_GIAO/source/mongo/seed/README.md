# Dữ liệu khởi tạo tùy chọn

`courses.json` và `students.json` chứa dữ liệu mẫu bên ngoài mã ứng dụng. Có thể chỉnh file JSON hoặc nhập dữ liệu riêng bằng MongoDB Compass.

Chỉ lệnh `npm.cmd run seed` đọc các file này để thêm bản ghi chưa có. Website và API không import các file mẫu, không dùng chúng làm dữ liệu dự phòng, không tự tạo lại dữ liệu khi database trống. `npm start` và `CHAY_DU_AN.cmd` không gọi seed.

Đối với database của nhóm, có thể bỏ qua hoàn toàn bước seed: tạo môn qua website và dùng hồ sơ sinh viên của module người 1.
