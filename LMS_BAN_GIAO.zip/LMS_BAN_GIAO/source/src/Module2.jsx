import React, { useState } from 'react';
import { BrowserRouter, Link, NavLink, Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { BookOpen, ChevronRight, CircleHelp, GraduationCap, LayoutDashboard, Menu, PanelLeftClose, ShieldCheck, Users, X, ListChecks } from 'lucide-react';
import { ApiProvider, useData } from './lib/api.jsx';
import { PageHeader, RouteScroll, ToastProvider } from './components/Common.jsx';
import Dashboard from './pages/Dashboard.jsx';
import { CourseList, CourseDetail, CourseForm, CourseDelete } from './pages/Courses.jsx';
import { GradeList, GradeForm, GradeDelete } from './pages/Grades.jsx';
import { StudentList, StudentDetail } from './pages/Students.jsx';
import StudentManagement from './pages/StudentManagement.jsx';

function Layout() {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  const health = useData('/health');
  const activeArea = location.pathname.startsWith('/courses') ? 'Môn học' : location.pathname.startsWith('/grades') ? 'Quản lý điểm' : location.pathname.startsWith('/students') ? 'Sinh viên' : location.pathname === '/guide' ? 'Hướng dẫn' : 'Tổng quan';
  const nav = [
  { to: '/dashboard', label: 'Tổng quan', icon: LayoutDashboard },
  { to: '/courses', label: 'Quản lý môn học', icon: BookOpen },
  { to: '/grades', label: 'Quản lý điểm', icon: ListChecks },
  { to: '/students', label: 'Danh sách sinh viên', icon: Users },
  { to: '/student-management', label: 'Quản lý sinh viên', icon: Users },
];
  return <div className="admin-app"><RouteScroll />{menuOpen && <button className="sidebar-overlay" aria-label="Đóng menu" onClick={() => setMenuOpen(false)} />}
    <aside className={`sidebar ${menuOpen ? 'open' : ''}`}><Link to="/dashboard" className="brand" onClick={() => setMenuOpen(false)}><span className="brand-mark"><GraduationCap size={25} /></span><span>learnspace<small>ADMIN WORKSPACE</small></span></Link><button className="mobile-close" aria-label="Đóng menu" onClick={() => setMenuOpen(false)}><X size={20} /></button>
      <div className="sidebar-workspace"><span className="workspace-symbol"><ShieldCheck size={18} /></span><div><strong>Quản trị đào tạo</strong><small>Không gian làm việc</small></div><ChevronRight size={14} /></div>
      <div className="nav-label">ĐIỀU HÀNH</div><nav aria-label="Menu quản trị">{nav.map(({ to, label, icon: Icon, end }) => <NavLink key={to} to={to} end={end} className={({ isActive }) => `nav-item ${(to === '/grades' ? location.pathname.startsWith('/grades') : isActive) ? 'selected' : ''}`} onClick={() => setMenuOpen(false)}><Icon size={18} /><span>{label}</span><span className="nav-indicator" /></NavLink>)}</nav>
      <div className="sidebar-spacer" /><div className="sidebar-help"><div className="help-symbol"><BookOpen size={20} /></div><strong>Mọi kết quả đều có ý nghĩa.</strong><p>Quản lý học phần và ghi nhận hành trình học tập của sinh viên.</p><Link to="/guide" onClick={() => setMenuOpen(false)}>Hướng dẫn sử dụng <ChevronRight size={14} /></Link></div>
      <NavLink to="/guide" className="help-link" onClick={() => setMenuOpen(false)}><CircleHelp size={17} />Trợ giúp & hướng dẫn</NavLink><div className="sidebar-account"><span className="account-avatar">QT</span><div><strong>Quản trị đào tạo</strong><small>Môn học & điểm số</small></div><ShieldCheck size={16} /></div>
    </aside>
    <div className="app-main"><header className="topbar"><div className="topbar-left"><button className="menu-button" aria-label="Mở menu" onClick={() => setMenuOpen(true)}><Menu size={21} /></button><PanelLeftClose size={17} className="desktop-menu-icon" /><span className="topbar-divider" /><Link to="/dashboard">Không gian quản trị</Link><ChevronRight size={12} /><strong>{activeArea}</strong></div><div className="topbar-right"><span className={`connection-dot ${health.data?.status === 'ok' ? 'online' : ''}`} /><span>{health.loading ? 'Đang kết nối' : health.error ? 'Mất kết nối' : 'Dữ liệu đã kết nối'}</span><span className="account-avatar mini">QT</span></div></header>
      <main id="main-content" className="page-content"><Outlet /></main><footer className="page-footer"><span>Learnspace <span className="footer-dot">·</span> Quản trị đào tạo</span><span>Không gian môn học & điểm số</span></footer>
    </div></div>;
}
function Guide() {
  return <><PageHeader title="Hướng dẫn sử dụng" description="Bắt đầu với các công việc quản lý đào tạo hằng ngày." /><div className="guide-grid">{[
    ['01', 'Quản lý danh mục môn học', 'Thêm môn học, điều chỉnh tên, số tín chỉ và trạng thái. Chuyển môn không dùng vào thùng rác; điểm cũ vẫn được giữ nguyên.', '/courses', 'Đi đến danh mục'],
    ['02', 'Nhập điểm cho sinh viên', 'Tìm sinh viên theo mã, chọn môn đang mở và nhập điểm từ 0 đến 10. Mỗi sinh viên chỉ có một điểm cho một môn học.', '/grades?entry=1', 'Nhập điểm mới'],
    ['03', 'Chỉnh sửa kết quả học tập', 'Tìm theo sinh viên hoặc môn trong trang quản lý điểm. Mỗi bản điểm có trang sửa và xác nhận xóa riêng.', '/grades', 'Quản lý điểm'],
  ].map(([step, title, text, to, label]) => <section className="card guide-card" key={step}><span className="step-number">{step}</span><h2>{title}</h2><p>{text}</p><Link className="btn secondary" to={to}>{label}<ChevronRight size={15} /></Link></section>)}</div><div className="info-callout"><ShieldCheck size={21} /><div><strong>Dữ liệu luôn được giữ đúng trách nhiệm</strong><p>Danh sách sinh viên dùng để tra cứu và nhập điểm. Thông tin hồ sơ được quản lý bởi module sinh viên của nhóm. Khi sửa môn học, điểm và tín chỉ đã ghi nhận trước đó được giữ nguyên.</p></div></div></>;
}
function LegacyGradeEntry() { const { search } = useLocation(); const params = new URLSearchParams(search); params.set('entry', '1'); return <Navigate to={`/grades?${params}`} replace />; }
function NotFound() { return <div className="not-found"><span>404</span><h1>Không tìm thấy trang</h1><p>Đường dẫn này không tồn tại trong không gian quản trị.</p><Link className="btn primary" to="/dashboard">Về tổng quan</Link></div>; }
export function AdminApp({ apiBase = '/api' }) {
    return <ApiProvider base={apiBase}><ToastProvider><Routes><Route element={<Layout />}>
    <Route index element={<Navigate to="/dashboard" replace />} /><Route path="dashboard" element={<Dashboard />} />
    <Route path="courses" element={<CourseList />} /><Route path="courses/trash" element={<CourseList trash />} /><Route path="courses/new" element={<CourseForm />} />
    <Route path="courses/:courseId" element={<CourseDetail />} /><Route path="courses/:courseId/edit" element={<CourseForm edit />} /><Route path="courses/:courseId/delete" element={<CourseDelete />} />
    <Route path="grades" element={<GradeList />} /><Route path="grades/new" element={<LegacyGradeEntry />} /><Route path="grades/:studentId/:courseId/edit" element={<GradeForm edit />} /><Route path="grades/:studentId/:courseId/delete" element={<GradeDelete />} />
    <Route path="students" element={<StudentList />} /><Route path="students/:studentId" element={<StudentDetail />} /><Route path="student-management" element={<StudentManagement />} /><Route path="guide" element={<Guide />} /><Route path="*" element={<NotFound />} />
  </Route></Routes></ToastProvider></ApiProvider>;
}
export default function Module2({ apiBase = '/api' }) { return <BrowserRouter><AdminApp apiBase={apiBase} /></BrowserRouter>; }
