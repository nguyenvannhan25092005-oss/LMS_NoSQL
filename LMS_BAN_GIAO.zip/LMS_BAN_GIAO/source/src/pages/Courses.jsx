import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { ArrowRight, BookOpen, ChevronRight, CircleAlert, Eye, Info, Pencil, Plus, RotateCcw, Save, ShieldCheck, Trash2 } from 'lucide-react';
import { idPath, useApi, useData } from '../lib/api.jsx';
import { FormError, PageHeader, Pagination, ScoreBadge, SearchBox, StateView, StatusBadge, TextLink, usePage, useToast } from '../components/Common.jsx';

export function CourseList({ trash = false }) {
  const result = useData(`/courses${trash ? '?trash=true' : ''}`);
  const [params, setParams] = useSearchParams();
  const [busy, setBusy] = useState(''), [error, setError] = useState('');
  const page = usePage(), api = useApi(), toast = useToast();
  const q = (params.get('q') || '').toLocaleLowerCase('vi'), status = params.get('status') || '';
  const filtered = (result.data || []).filter((course) => `${course.course_id} ${course.course_name}`.toLocaleLowerCase('vi').includes(q) && (!status || (course.status || 'active') === status));
  const rows = filtered.slice((page - 1) * 8, page * 8);
  async function restore(course) {
    setBusy(course.course_id); setError('');
    try { const response = await api(`/courses/${idPath(course.course_id)}/restore`, { method: 'POST' }); toast(response.message); result.reload(); }
    catch (err) { setError(err.message); } finally { setBusy(''); }
  }
  return <><PageHeader title={trash ? 'Thùng rác môn học' : 'Quản lý môn học'} description={trash ? 'Khôi phục các môn đã chuyển vào thùng rác. Điểm đã ghi nhận vẫn được bảo toàn.' : 'Xây dựng và quản lý danh mục môn học của chương trình đào tạo.'} action={!trash && <Link className="btn primary" to="/courses/new"><Plus size={17} />Thêm môn học</Link>} />
    <section className="card"><div className="list-tabs"><Link className={!trash ? 'active' : ''} to="/courses"><BookOpen size={15} />Danh mục môn học{!trash && result.data && <span>{result.data.length}</span>}</Link><Link className={trash ? 'active' : ''} to="/courses/trash"><Trash2 size={15} />Thùng rác{trash && result.data && <span>{result.data.length}</span>}</Link></div>
      <div className="list-toolbar"><SearchBox placeholder="Tìm mã hoặc tên môn học…" />{!trash && <select className="filter-select" aria-label="Lọc trạng thái" value={status} onChange={(event) => { const next = new URLSearchParams(params); if (event.target.value) next.set('status', event.target.value); else next.delete('status'); next.delete('page'); setParams(next); }}><option value="">Tất cả trạng thái</option><option value="active">Mở</option><option value="inactive">Đóng</option></select>}</div><FormError message={error} />
      <StateView {...result} retry={result.reload} empty={!rows.length} title={trash && !q ? 'Thùng rác đang trống' : undefined}><div className="table-scroll"><table><thead><tr><th className="index-cell">STT</th><th>MÔN HỌC</th><th>MÃ MÔN</th><th>TÍN CHỈ</th><th>TRẠNG THÁI</th><th className="align-right">THAO TÁC</th></tr></thead><tbody>{rows.map((course, index) => <tr key={course.course_id}><td className="muted index-cell">{String((page - 1) * 8 + index + 1).padStart(2, '0')}</td><td><Link className="course-cell" to={`/courses/${idPath(course.course_id)}`}><span className={`course-icon tone-${index % 3}`}><BookOpen size={18} /></span><strong>{course.course_name}</strong></Link></td><td><span className="code-tag">{course.course_id}</span></td><td><span className="credit-badge">{course.credits}</span></td><td><StatusBadge course={course} /></td><td><div className="row-actions">{trash ? <button className="btn small secondary" disabled={!!busy} onClick={() => restore(course)}><RotateCcw size={14} />{busy === course.course_id ? 'Đang khôi phục…' : 'Khôi phục'}</button> : <><Link className="icon-button" aria-label={`Xem môn ${course.course_id}`} to={`/courses/${idPath(course.course_id)}`}><Eye size={16} /></Link><Link className="icon-button" aria-label={`Sửa môn ${course.course_id}`} to={`/courses/${idPath(course.course_id)}/edit`}><Pencil size={16} /></Link><Link className="icon-button danger-icon" aria-label={`Xóa môn ${course.course_id}`} to={`/courses/${idPath(course.course_id)}/delete`}><Trash2 size={16} /></Link></>}</div></td></tr>)}</tbody></table></div></StateView>
      {result.data && <Pagination page={page} pages={Math.ceil(filtered.length / 8)} total={filtered.length} limit={8} />}
    </section><div className="list-footnote"><Info size={14} /><span>Mỗi mã môn là duy nhất. Điểm đã ghi nhận được giữ nguyên khi danh mục thay đổi.</span></div></>;
}

export function CourseForm({ edit = false }) {
  const { courseId } = useParams();
  const result = useData(edit ? `/courses/${idPath(courseId)}` : null);
  const [fields, setFields] = useState({ course_id: '', course_name: '', credits: '3', status: 'active' });
  const [busy, setBusy] = useState(false), [error, setError] = useState('');
  const api = useApi(), navigate = useNavigate(), toast = useToast();
  useEffect(() => {
    setError('');
    setFields(result.data ? { ...result.data, credits: String(result.data.credits), status: result.data.status || 'active' } : { course_id: '', course_name: '', credits: '3', status: 'active' });
  }, [result.data, edit, courseId]);
  const set = (key) => (event) => setFields((old) => ({ ...old, [key]: event.target.value }));
  async function save(event) {
    event.preventDefault(); setBusy(true); setError('');
    try {
      const response = await api(edit ? `/courses/${idPath(courseId)}` : '/courses', { method: edit ? 'PUT' : 'POST', body: { ...fields, credits: Number(fields.credits) } });
      toast(response.message); navigate(`/courses/${idPath(edit ? courseId : fields.course_id.trim())}`);
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  }
  return <><PageHeader title={edit ? 'Chỉnh sửa môn học' : 'Thêm môn học mới'} description={edit ? 'Cập nhật thông tin trong danh mục môn học.' : 'Tạo môn học và thiết lập số tín chỉ trước khi nhập điểm.'} back={{ to: '/courses', label: 'Danh mục môn học' }} />
    <StateView {...result} retry={result.reload}>{result.data?.deleted_at ? <div className="info-callout"><Info /><div>Môn học đang ở thùng rác. Vui lòng khôi phục trước khi sửa.<p><Link to="/courses/trash">Mở thùng rác</Link></p></div></div> : <div className="course-form-layout"><section className="card form-card"><div className="card-heading"><div><h2>Thông tin môn học</h2><p>Các trường có dấu <span className="required">*</span> là bắt buộc.</p></div><span className="icon-tile green"><BookOpen size={20} /></span></div><form onSubmit={save}><fieldset disabled={busy}><div className="form-grid"><div className="field"><label htmlFor="course-code">Mã môn học <em>*</em></label><input id="course-code" required maxLength={64} pattern="[A-Za-z0-9_-]+" placeholder="VD: MH006" disabled={edit} value={fields.course_id} onChange={set('course_id')} /><small>{edit ? 'Mã định danh không thay đổi sau khi tạo.' : 'Chỉ dùng chữ, số, dấu gạch ngang hoặc gạch dưới.'}</small></div><div className="field"><label htmlFor="credits">Số tín chỉ <em>*</em></label><input id="credits" type="number" min="1" max="30" step="1" required value={fields.credits} onChange={set('credits')} /></div><div className="field full"><label htmlFor="course-name">Tên môn học <em>*</em></label><input id="course-name" required maxLength={150} placeholder="VD: Phân tích và thiết kế hệ thống" value={fields.course_name} onChange={set('course_name')} /></div><div className="field full"><label htmlFor="course-status">Trạng thái</label><select id="course-status" value={fields.status} onChange={set('status')}><option value="active">Mở</option><option value="inactive">Đóng</option></select><small>Môn đã đóng không nhận điểm mới; vẫn có thể chỉnh sửa điểm đã ghi nhận.</small></div></div><FormError message={error} /><div className="form-actions"><Link className="btn secondary" to="/courses">Hủy bỏ</Link><button className="btn primary" type="submit" disabled={busy}><Save size={16} />{busy ? 'Đang lưu…' : edit ? 'Lưu thay đổi' : 'Tạo môn học'}</button></div></fieldset></form></section></div>}</StateView></>;
}

export function CourseDetail() {
  const { courseId } = useParams();
  const result = useData(`/courses/${idPath(courseId)}`);
  const grades = useData(`/module2/grades?course_id=${idPath(courseId)}&limit=5`);
  const course = result.data;
  return <><PageHeader title="Chi tiết môn học" description="Thông tin danh mục và các kết quả học tập liên quan." back={{ to: '/courses', label: 'Danh mục môn học' }} action={course && !course.deleted_at && <Link className="btn primary" to={`/courses/${idPath(courseId)}/edit`}><Pencil size={16} />Chỉnh sửa môn học</Link>} />
    <StateView {...result} retry={result.reload}>{course && <><div className="course-detail-hero card"><span className="detail-course-icon"><BookOpen size={32} /></span><div><span className="code-tag">{course.course_id}</span><h2>{course.course_name}</h2><StatusBadge course={course} /></div><div className="detail-metric"><strong>{course.credits}</strong><span>Tín chỉ</span></div><div className="detail-metric"><strong>{course.grade_count}</strong><span>Sinh viên có điểm</span></div></div>
      <div className="detail-toolbar"><div className="list-footnote"><Info size={15} />Điểm đã lưu giữ nguyên thông tin môn học tại thời điểm nhập.</div>{!course.deleted_at && course.status !== 'inactive' && <Link className="btn secondary" to={`/grades?entry=1&course_id=${idPath(courseId)}`}><Plus size={15} />Nhập điểm môn này</Link>}</div>
      <section className="card"><div className="card-heading"><div><h2>Điểm sinh viên</h2><p>Một số kết quả đã ghi nhận cho môn học</p></div><TextLink to={`/grades?course_id=${idPath(courseId)}`}>Xem danh sách</TextLink></div><StateView {...grades} retry={grades.reload} empty={!grades.data?.length} title="Chưa có sinh viên được nhập điểm"><div className="table-scroll"><table><thead><tr><th>SINH VIÊN</th><th>MÃ SINH VIÊN</th><th>ĐIỂM SỐ</th><th /></tr></thead><tbody>{grades.data?.map((row) => <tr key={row.student_id}><td><strong>{row.full_name || row.student_id}</strong></td><td><span className="code-tag">{row.student_id}</span></td><td><ScoreBadge score={row.grade.score} /></td><td><Link className="text-link" to={`/grades/${idPath(row.student_id)}/${idPath(courseId)}/edit`}>Sửa điểm<ChevronRight size={14} /></Link></td></tr>)}</tbody></table></div></StateView></section></>}</StateView></>;
}

export function CourseDelete() {
  const { courseId } = useParams();
  const result = useData(`/courses/${idPath(courseId)}`), api = useApi(), navigate = useNavigate(), toast = useToast();
  const [busy, setBusy] = useState(false), [error, setError] = useState('');
  async function remove(event) {
    event.preventDefault(); setBusy(true); setError('');
    try { const response = await api(`/courses/${idPath(courseId)}`, { method: 'DELETE' }); toast(response.message); navigate('/courses'); }
    catch (err) { setError(err.message); } finally { setBusy(false); }
  }
  return <><PageHeader title="Xóa môn học" description="Kiểm tra thông tin trước khi chuyển môn vào thùng rác." back={{ to: '/courses', label: 'Danh mục môn học' }} /><StateView {...result} retry={result.reload}>{result.data && <section className="card confirm-card"><span className="confirm-icon"><Trash2 size={29} /></span><h2>Chuyển môn học vào thùng rác?</h2><p>Môn sẽ không còn trong danh mục đang mở và không nhận điểm mới.</p><div className="confirm-record"><span>{result.data.course_id}</span><strong>{result.data.course_name}</strong><small>{result.data.credits} tín chỉ · {result.data.grade_count} sinh viên có điểm</small></div><div className="info-callout compact"><ShieldCheck size={19} /><span>Điểm đã ghi nhận được giữ nguyên. Bạn có thể khôi phục môn từ thùng rác.</span></div><FormError message={error} /><form onSubmit={remove}><label className="checkbox-label"><input type="checkbox" required disabled={busy || !!result.data.deleted_at} />Tôi xác nhận chuyển môn học này vào thùng rác.</label><div className="form-actions"><Link className="btn secondary" to="/courses">Hủy bỏ</Link><button className="btn danger" disabled={busy || !!result.data.deleted_at}><Trash2 size={16} />{busy ? 'Đang xử lý…' : 'Chuyển vào thùng rác'}</button></div></form></section>}</StateView></>;
}
