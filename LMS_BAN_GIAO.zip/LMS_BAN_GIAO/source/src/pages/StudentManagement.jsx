
import React, { useEffect, useState } from 'react';
import { Plus, RefreshCw, Save, X, Users, Pencil } from 'lucide-react';

export default function StudentManagement() {
    const [students, setStudents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [showForm, setShowForm] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);

    const [form, setForm] = useState({
        student_id: '',
        full_name: '',
        class_name: '',
        email: ''
    });

    async function loadStudents() {
        setLoading(true);

        try {
            const response = await fetch(
                `/api/module2/students?page=${page}`
            );

            if (!response.ok) {
                throw new Error('Không thể tải danh sách sinh viên.');
            }

            const result = await response.json();

            setStudents(result.data || []);
            setTotalPages(result.pagination?.pages || 1);
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        loadStudents();
    }, [page]);

    async function handleEdit(student) {
        setError('');
        setMessage('');

        try {
            const response = await fetch(
                `/api/module1/students/${encodeURIComponent(student.student_id)}`
            );

            const result = await response.json();

            if (!response.ok) {
                throw new Error(
                    result.error?.message || 'Không thể tải hồ sơ sinh viên.'
                );
            }

            const detail = result.data;

            setEditingId(detail.student_id);

            setForm({
                student_id: detail.student_id,
                full_name: detail.full_name || '',
                class_name: detail.class_name || '',
                email: detail.email || ''
            });

            setShowForm(true);
        } catch (err) {
            setError(err.message);
        }
    }

    function handleChange(event) {
        const { name, value } = event.target;

        setForm(previous => ({
            ...previous,
            [name]: value
        }));
    }

    async function handleSubmit(event) {
        event.preventDefault();

        setMessage('');
        setError('');

        if (!form.student_id.trim() || !form.full_name.trim()) {
            setError('Vui lòng nhập mã và họ tên sinh viên.');
            return;
        }

        setSaving(true);

        try {
            const response = await fetch(
                editingId
                    ? `/api/module1/students/${encodeURIComponent(editingId)}`
                    : '/api/module1/students',
                {
                    method: editingId ? 'PUT' : 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(form)
                });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(
                    result.error?.message || 'Không thể thêm sinh viên.'
                );
            }

            setMessage(
                editingId
                    ? 'Cập nhật sinh viên thành công!'
                    : 'Thêm sinh viên thành công!'
            );

            setForm({
                student_id: '',
                full_name: '',
                class_name: '',
                email: ''
            });
            setEditingId(null);
            setShowForm(false);
            await loadStudents();
        } catch (err) {
            setError(err.message);
        } finally {
            setSaving(false);
        }
    }

    return (
        <div>
            <div className="page-header">
                <div>
                    <h1>Quản lý sinh viên</h1>
                    <p>
                        Quản lý hồ sơ và thông tin sinh viên trong hệ thống LMS.
                    </p>
                </div>
            </div>

            <section className="card">
                <div className="card-heading">
                    <div>
                        <h2>Danh sách sinh viên</h2>
                        <p>Thông tin được lấy trực tiếp từ MongoDB.</p>
                    </div>

                    <div className="row-actions">
                        <button
                            className="btn secondary"
                            onClick={loadStudents}
                            type="button"
                        >
                            <RefreshCw size={16} />
                            Làm mới
                        </button>

                        <button
                            className="btn primary"
                            onClick={() => {
                                setEditingId(null);
                                setForm({
                                    student_id: '',
                                    full_name: '',
                                    class_name: '',
                                    email: ''
                                });
                                setShowForm(true);
                                setError('');
                                setMessage('');
                            }}
                            type="button"
                        >
                            <Plus size={16} />
                            Thêm sinh viên
                        </button>
                    </div>
                </div>

                {message && (
                    <p role="status" style={{ color: 'green', padding: 12 }}>
                        {message}
                    </p>
                )}

                {error && (
                    <p role="alert" style={{ color: 'red', padding: 12 }}>
                        {error}
                    </p>
                )}

                {showForm && (
                    <form
                        onSubmit={handleSubmit}
                        style={{
                            padding: 20,
                            marginBottom: 20,
                            border: '1px solid #ddd',
                            borderRadius: 12
                        }}
                    >
                        <h3>{editingId ? 'Sửa thông tin sinh viên' : 'Thêm sinh viên mới'}</h3>

                        <div style={{ display: 'grid', gap: 12 }}>
                            <label>
                                Mã sinh viên *
                                <input
                                    type="text"
                                    name="student_id"
                                    value={form.student_id}
                                    onChange={handleChange}
                                    required
                                    maxLength={30}
                                    placeholder="Ví dụ: SV012"
                                    style={{ width: '100%', padding: 10 }}
                                />
                            </label>

                            <label>
                                Họ và tên *
                                <input
                                    type="text"
                                    name="full_name"
                                    value={form.full_name}
                                    onChange={handleChange}
                                    required
                                    placeholder="Nguyễn Văn A"
                                    style={{ width: '100%', padding: 10 }}
                                />
                            </label>

                            <label>
                                Lớp học
                                <input
                                    type="text"
                                    name="class_name"
                                    value={form.class_name}
                                    onChange={handleChange}
                                    placeholder="CNTT01"
                                    style={{ width: '100%', padding: 10 }}
                                />
                            </label>

                            <label>
                                Email
                                <input
                                    type="email"
                                    name="email"
                                    value={form.email}
                                    onChange={handleChange}
                                    placeholder="student@example.com"
                                    style={{ width: '100%', padding: 10 }}
                                />
                            </label>
                        </div>

                        <div
                            className="row-actions"
                            style={{ marginTop: 20 }}
                        >
                            <button
                                type="submit"
                                className="btn primary"
                                disabled={saving}
                            >
                                <Save size={16} />
                                {saving ? 'Đang lưu...' : 'Lưu sinh viên'}
                            </button>

                            <button
                                type="button"
                                className="btn secondary"
                                onClick={() => setShowForm(false)}
                            >
                                <X size={16} />
                                Hủy
                            </button>
                        </div>
                    </form>
                )}

                {loading ? (
                    <p style={{ padding: 20 }}>Đang tải dữ liệu...</p>
                ) : (
                    <div className="table-scroll">
                        <table>
                            <thead>
                                <tr>
                                    <th>MÃ SINH VIÊN</th>
                                    <th>HỌ VÀ TÊN</th>
                                    <th>LỚP</th>
                                    <th>SỐ MÔN CÓ ĐIỂM</th>
                                    <th>THAO TÁC</th>
                                </tr>
                            </thead>

                            <tbody>
                                {students.map(student => (
                                    <tr key={student.student_id}>
                                        <td>
                                            <span className="code-tag">
                                                {student.student_id}
                                            </span>
                                        </td>
                                        <td>
                                            <strong>{student.full_name}</strong>
                                        </td>
                                        <td>{student.class_name || '—'}</td>
                                        <td>{student.grade_count ?? 0}</td>
                                        <td>
                                            <button
                                                type="button"
                                                className="btn small secondary"
                                                onClick={() => handleEdit(student)}
                                            >
                                                <Pencil size={14} />
                                                Sửa
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>

                        {students.length === 0 && (
                            <p style={{ padding: 20 }}>
                                <Users size={16} />
                                Chưa có sinh viên.
                            </p>
                        )}
                    </div>
                )}

                <div
                    className="row-actions"
                    style={{ padding: 16, justifyContent: 'center' }}
                >
                    <button
                        className="btn secondary"
                        type="button"
                        disabled={page <= 1}
                        onClick={() => setPage(p => p - 1)}
                    >
                        Trang trước
                    </button>

                    <span>Trang {page} / {totalPages}</span>

                    <button
                        className="btn secondary"
                        type="button"
                        disabled={page >= totalPages}
                        onClick={() => setPage(p => p + 1)}
                    >
                        Trang sau
                    </button>
                </div>
            </section>
        </div>
    );
}
