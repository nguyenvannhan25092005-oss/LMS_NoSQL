import React, { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { ArrowRight, CheckCircle2, FileCheck2, Info, Pencil, Plus, Save, Search, ShieldCheck, Trash2, UserRound, X } from 'lucide-react';
import { idPath, useApi, useData } from '../lib/api.jsx';
import { FormError, PageHeader, Pagination, ScoreBadge, SearchBox, StateView, usePage, useToast } from '../components/Common.jsx';

export function GradeList() {
  const [params, setParams] = useSearchParams(), page = usePage();
  const entering = params.get('entry') === '1' || params.get('tab') === 'entry';
  const [entryBusy, setEntryBusy] = useState(false);
  function openEntry() { const next = new URLSearchParams(params); next.delete('tab'); next.set('entry', '1'); setParams(next); }
  function closeEntry(studentId) { const next = new URLSearchParams(params); next.delete('entry'); next.delete('tab'); next.delete('student_id'); if (typeof studentId === 'string') { next.set('q', studentId); next.delete('page'); } setEntryBusy(false); setParams(next); }
  function saved(studentId) { closeEntry(studentId); result.reload(); }
  const q = params.get('q') || '', courseId = params.get('course_id') || '';
  const result = useData(`/module2/grades?${new URLSearchParams({ q, page, ...(courseId ? { course_id: courseId } : {}) })}`);
  const courses = useData('/courses');
  return <><PageHeader title="Quản lý điểm" description="Tra cứu, chỉnh sửa và quản lý từng kết quả học tập của sinh viên." action={<button className="btn primary" onClick={openEntry}><Plus size={17} />Nhập điểm mới</button>} /><section className="card"><div className="card-heading"><div><h2>Danh sách điểm sinh viên</h2><p>Mỗi dòng là kết quả của một sinh viên trong một môn học.</p></div><span className="count-label">{result.pagination?.total ?? '—'} bản điểm</span></div><div className="list-toolbar"><SearchBox placeholder="Tìm mã, tên sinh viên hoặc môn học…" /><select className="filter-select" aria-label="Lọc môn học" value={courseId} onChange={(event) => { const next = new URLSearchParams(params); if (event.target.value) next.set('course_id', event.target.value); else next.delete('course_id'); next.delete('page'); setParams(next); }}><option value="">Tất cả môn học</option>{courseId && !courses.data?.some((course) => course.course_id === courseId) && <option value={courseId}>{courseId} · Môn trong lịch sử</option>}{courses.data?.map((course) => <option key={course.course_id} value={course.course_id}>{course.course_id} · {course.course_name}</option>)}</select></div>
    <StateView {...result} retry={result.reload} empty={!result.data?.length}><div className="table-scroll"><table><thead><tr><th>SINH VIÊN</th><th>MÔN HỌC</th><th>TÍN CHỈ</th><th>ĐIỂM SỐ</th><th className="align-right">THAO TÁC</th></tr></thead><tbody>{result.data?.map((row) => <tr key={`${row.student_id}-${row.grade.course_id}`}><td><Link className="person-cell" to={`/students/${idPath(row.student_id)}`}><span className="person-avatar">{row.full_name?.split(' ').at(-1)?.slice(0, 1) || 'S'}</span><span><strong>{row.full_name || row.student_id}</strong><small>{row.student_id} {row.class_name && `· ${row.class_name}`}</small></span></Link></td><td><strong className="cell-title">{row.grade.course_name}</strong><small className="cell-sub">{row.grade.course_id}</small></td><td><span className="credit-badge">{row.grade.credits}</span></td><td><ScoreBadge score={row.grade.score} /></td><td><div className="row-actions"><Link className="icon-button" aria-label={`Sửa điểm ${row.student_id} ${row.grade.course_id}`} to={`/grades/${idPath(row.student_id)}/${idPath(row.grade.course_id)}/edit`}><Pencil size={16} /></Link><Link className="icon-button danger-icon" aria-label={`Xóa điểm ${row.student_id} ${row.grade.course_id}`} to={`/grades/${idPath(row.student_id)}/${idPath(row.grade.course_id)}/delete`}><Trash2 size={16} /></Link></div></td></tr>)}</tbody></table></div></StateView>{result.pagination && <Pagination {...result.pagination} />}</section><div className="list-footnote"><ShieldCheck size={15} />Thay đổi điểm không ghi đè thông tin hồ sơ hoặc điểm của môn học khác.</div>{entering && <GradeEntryDialog busy={entryBusy} onClose={() => closeEntry()}><NewGrade embedded onSaved={saved} onCancel={() => closeEntry()} onBusy={setEntryBusy} /></GradeEntryDialog>}</>;
}

function GradeEntryDialog({ children, onClose, busy }) {
  const dialog = useRef(null);
  useEffect(() => {
    const previousFocus = document.activeElement;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    (dialog.current.querySelector('input:not([disabled])') || dialog.current).focus();
    return () => { document.body.style.overflow = overflow; if (previousFocus?.isConnected) previousFocus.focus(); };
  }, []);
  function keys(event) {
    if (event.key === 'Escape') { event.preventDefault(); if (!busy) onClose(); }
    if (event.key === 'Tab') {
      const items = [...dialog.current.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),a[href],[tabindex="0"]')].filter((item) => item.getClientRects().length && !item.matches(':disabled'));
      const first = items[0], last = items.at(-1);
      if (!first) { event.preventDefault(); return; }
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  }
  return <div className="grade-modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget && !busy) onClose(); }}><section className="grade-entry-dialog" role="dialog" aria-modal="true" aria-labelledby="grade-entry-title" ref={dialog} tabIndex={-1} onKeyDown={keys}><header className="grade-modal-header"><div><h2 id="grade-entry-title">Nhập điểm mới</h2><p>Chọn sinh viên và môn học để ghi nhận kết quả.</p></div><button className="icon-button" aria-label="Đóng cửa sổ nhập điểm" disabled={busy} onClick={onClose}><X size={19} /></button></header>{children}</section></div>;
}

export function GradeForm({ edit = false }) { return edit ? <EditGrade /> : <NewGrade />; }

function NewGrade({ embedded = false, onSaved, onCancel, onBusy }) {
  const [params] = useSearchParams();
  const [studentInput, setStudentInput] = useState(params.get('student_id') || '');
  const [selectedId, setSelectedId] = useState(params.get('student_id') || '');
  const [courseId, setCourseId] = useState(params.get('course_id') || '');
  const [score, setScore] = useState(''), [busy, setBusy] = useState(false), [error, setError] = useState('');
  useEffect(() => { onBusy?.(busy); }, [busy, onBusy]);
  const student = useData(selectedId ? `/module2/students/${idPath(selectedId)}` : null);
  const courses = useData('/courses');
  const api = useApi(), navigate = useNavigate(), toast = useToast();
  const available = (courses.data || []).filter((course) => course.status !== 'inactive');
  const existing = student.data?.grades.find((grade) => grade.course_id === courseId);
  const selectedCourse = available.find((course) => course.course_id === courseId);
  async function save(event) {
    event.preventDefault();
    if (!student.data || !selectedCourse || existing || !score.trim()) return;
    setBusy(true); setError('');
    try { const response = await api('/grades', { method: 'POST', body: { student_id: student.data.student_id, course_id: courseId, score: Number(score) } }); toast(response.message); if (onSaved) onSaved(student.data.student_id); else navigate(`/grades?q=${idPath(student.data.student_id)}`); }
    catch (err) { setError(err.message); } finally { setBusy(false); }
  }
  return <>{!embedded && <PageHeader title="Nhập điểm mới" description="Chọn đúng sinh viên và môn học trước khi ghi nhận kết quả." back={{ to: '/grades', label: 'Quản lý điểm' }} />}<div className="form-layout"><section className="card form-card"><div className="card-heading"><div><h2>Ghi nhận kết quả học tập</h2><p>Điểm được lưu riêng cho từng sinh viên và môn học.</p></div><span className="icon-tile green"><FileCheck2 size={20} /></span></div>
    <div className="form-section"><h3><span className="step-dot">1</span>Tra cứu sinh viên</h3><form className="student-lookup" onSubmit={(event) => { event.preventDefault(); setSelectedId(studentInput.trim()); if (selectedId === studentInput.trim()) student.reload(); setError(''); }}><label htmlFor="student-code">Mã sinh viên <em>*</em></label><div className="lookup-row"><input id="student-code" required maxLength={64} placeholder="VD: SV010" value={studentInput} disabled={busy} onChange={(event) => { setStudentInput(event.target.value); setSelectedId(''); setError(''); }} /><button className="btn secondary" disabled={busy || student.loading}><Search size={16} />Tra cứu</button></div></form>
      {selectedId && <StateView {...student} retry={student.reload}>{student.data && <div className="student-found"><span className="person-avatar"><UserRound size={20} /></span><div><strong>{student.data.full_name || student.data.student_id}</strong><small>{student.data.student_id}{student.data.class_name && ` · ${student.data.class_name}`}</small></div><CheckCircle2 size={19} /></div>}</StateView>}
      {!selectedId && <div className="field-hint">Nhập mã và bấm Tra cứu, hoặc chọn từ <Link to="/students">danh sách sinh viên</Link>.</div>}</div>
    <form onSubmit={save}><fieldset disabled={busy}><div className="form-section"><h3><span className="step-dot">2</span>Thông tin điểm số</h3><div className="field"><label htmlFor="grade-course">Môn học <em>*</em></label><select id="grade-course" required value={courseId} disabled={courses.loading} onChange={(event) => { setCourseId(event.target.value); setError(''); }}><option value="">Chọn môn học đang mở</option>{available.map((course) => <option key={course.course_id} value={course.course_id}>{course.course_id} · {course.course_name} ({course.credits} tín chỉ)</option>)}</select>{courses.error && <FormError message={courses.error} />}{!courses.loading && !courses.error && !available.length && <small>Chưa có môn đang mở. <Link to="/courses/new">Thêm môn học</Link> trước khi nhập điểm.</small>}</div><div className="field score-field"><label htmlFor="new-score">Điểm số <em>*</em><span>Thang điểm 10</span></label><div className="score-input"><input id="new-score" type="number" min="0" max="10" step="any" required placeholder="0.0" value={score} onChange={(event) => setScore(event.target.value)} /><span>/ 10</span></div><small>Chấp nhận điểm từ 0 đến 10, bao gồm điểm thập phân.</small></div>
      {existing && <div className="info-callout compact"><Info size={18} /><span>Sinh viên đã có điểm môn này: <strong>{existing.score}</strong>. <Link to={`/grades/${idPath(student.data.student_id)}/${idPath(courseId)}/edit`}>Chuyển sang trang sửa điểm <ArrowRight size={12} /></Link></span></div>}<FormError message={error} /></div><div className="form-actions">{onCancel ? <button type="button" className="btn secondary" disabled={busy} onClick={onCancel}>Hủy bỏ</button> : <Link className="btn secondary" to="/grades">Hủy bỏ</Link>}<button className="btn primary" disabled={busy || !student.data || !selectedCourse || !!existing || student.loading}><Save size={16} />{busy ? 'Đang lưu…' : 'Lưu điểm mới'}</button></div></fieldset></form>
    </section><aside className="form-aside"><div className="aside-icon"><ShieldCheck size={23} /></div><h3>Đúng người, đúng môn</h3><p>Kiểm tra tên sinh viên hiển thị sau khi tra cứu trước khi lưu điểm.</p><ul><li>Mỗi sinh viên có một bản điểm cho mỗi môn.</li><li>Điểm 0 là một kết quả hợp lệ.</li><li>Tên môn và tín chỉ tự lấy từ danh mục.</li></ul>{selectedCourse && <div className="aside-summary"><span>MÔN ĐANG CHỌN</span><strong>{selectedCourse.course_name}</strong><small>{selectedCourse.course_id} · {selectedCourse.credits} tín chỉ</small></div>}</aside></div></>;
}

function EditGrade() {
  const { studentId, courseId } = useParams();
  const result = useData(`/module2/students/${idPath(studentId)}`), api = useApi(), navigate = useNavigate(), toast = useToast();
  const grade = result.data?.grades.find((item) => item.course_id === courseId);
  const [score, setScore] = useState(''), [busy, setBusy] = useState(false), [error, setError] = useState('');
  useEffect(() => { setScore(grade ? String(grade.score) : ''); setError(''); }, [grade]);
  async function save(event) {
    event.preventDefault(); setBusy(true); setError('');
    try { const response = await api(`/grades/${idPath(studentId)}/${idPath(courseId)}`, { method: 'PUT', body: { score: Number(score) } }); toast(response.message); navigate(`/grades?q=${idPath(studentId)}`); }
    catch (err) { setError(err.message); } finally { setBusy(false); }
  }
  return <><PageHeader title="Chỉnh sửa điểm" description="Điều chỉnh kết quả của một sinh viên trong môn học đã ghi nhận." back={{ to: '/grades', label: 'Quản lý điểm' }} /><StateView {...result} retry={result.reload}>{result.data && (grade ? <div className="form-layout"><section className="card form-card"><div className="card-heading"><div><h2>Thông tin bản điểm</h2><p>Chỉ điểm số được thay đổi trong thao tác này.</p></div><span className="icon-tile amber"><Pencil size={20} /></span></div><div className="record-summary"><div><span>SINH VIÊN</span><strong>{result.data.full_name || studentId}</strong><small>{studentId}{result.data.class_name && ` · ${result.data.class_name}`}</small></div><div><span>MÔN HỌC</span><strong>{grade.course_name}</strong><small>{courseId} · {grade.credits} tín chỉ</small></div></div><form onSubmit={save}><fieldset disabled={busy}><div className="form-section"><div className="previous-score"><span>Điểm hiện tại</span><ScoreBadge score={grade.score} /></div><div className="field score-field"><label htmlFor="edit-score">Điểm mới <em>*</em><span>Thang điểm 10</span></label><div className="score-input"><input id="edit-score" type="number" min="0" max="10" step="any" required value={score} onChange={(event) => setScore(event.target.value)} /><span>/ 10</span></div></div><FormError message={error} /></div><div className="form-actions"><Link className="btn secondary" to="/grades">Hủy bỏ</Link><button className="btn primary" disabled={busy}><Save size={16} />{busy ? 'Đang lưu…' : 'Lưu thay đổi'}</button></div></fieldset></form></section><aside className="form-aside"><div className="aside-icon"><ShieldCheck size={23} /></div><h3>Bảo toàn hồ sơ học tập</h3><p>Thao tác này chỉ sửa điểm của {studentId} trong môn {courseId}.</p><ul><li>Không tạo thêm bản điểm trùng.</li><li>Không thay đổi điểm môn học khác.</li><li>Giữ nguyên tín chỉ và tên môn đã ghi nhận.</li></ul><Link className="text-link danger-text" to={`/grades/${idPath(studentId)}/${idPath(courseId)}/delete`}><Trash2 size={14} />Xóa bản điểm này</Link></aside></div> : <div className="card"><StateView empty title="Không tìm thấy bản điểm" /><div className="empty-actions"><Link className="btn secondary" to="/grades">Về danh sách điểm</Link></div></div>)}</StateView></>;
}

export function GradeDelete() {
  const { studentId, courseId } = useParams();
  const result = useData(`/module2/students/${idPath(studentId)}`), api = useApi(), navigate = useNavigate(), toast = useToast();
  const grade = result.data?.grades.find((item) => item.course_id === courseId);
  const [busy, setBusy] = useState(false), [error, setError] = useState('');
  async function remove(event) {
    event.preventDefault(); setBusy(true); setError('');
    try { const response = await api(`/grades/${idPath(studentId)}/${idPath(courseId)}`, { method: 'DELETE' }); toast(response.message); navigate(`/grades?q=${idPath(studentId)}`); }
    catch (err) { setError(err.message); } finally { setBusy(false); }
  }
  return <><PageHeader title="Xóa bản điểm" description="Xác nhận đúng sinh viên và môn học trước khi xóa kết quả." back={{ to: '/grades', label: 'Quản lý điểm' }} /><StateView {...result} retry={result.reload}>{result.data && (grade ? <section className="card confirm-card"><span className="confirm-icon"><Trash2 size={29} /></span><h2>Bạn muốn xóa bản điểm này?</h2><p>Bản điểm sẽ được gỡ khỏi hồ sơ học tập. Muốn khôi phục, bạn cần nhập lại điểm.</p><div className="confirm-record"><span>{studentId} · {courseId}</span><strong>{result.data.full_name || studentId}</strong><small>{grade.course_name} · {grade.credits} tín chỉ</small><ScoreBadge score={grade.score} /></div><div className="info-callout compact"><Info size={18} /><span>Chỉ bản điểm này bị xóa. Hồ sơ sinh viên và điểm các môn khác vẫn được giữ nguyên.</span></div><FormError message={error} /><form onSubmit={remove}><label className="checkbox-label"><input type="checkbox" required disabled={busy} />Tôi xác nhận xóa điểm môn {courseId} của {studentId}.</label><div className="form-actions"><Link className="btn secondary" to="/grades">Hủy bỏ</Link><button className="btn danger" disabled={busy}><Trash2 size={16} />{busy ? 'Đang xóa…' : 'Xác nhận xóa điểm'}</button></div></form></section> : <StateView empty title="Không tìm thấy bản điểm để xóa" />)}</StateView></>;
}
