import React, { createContext, useContext, useEffect, useState } from 'react';
import { Link, useLocation, useSearchParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, CheckCircle2, ChevronLeft, ChevronRight, CircleAlert, LoaderCircle, Search, X } from 'lucide-react';
const ToastContext = createContext(() => {});
export const useToast = () => useContext(ToastContext);
export function ToastProvider({ children }) {
  const [message, setMessage] = useState('');
  useEffect(() => { if (message) { const timer = setTimeout(() => setMessage(''), 7000); return () => clearTimeout(timer); } }, [message]);
  return <ToastContext.Provider value={setMessage}>{children}{message && <div className="toast" role="status"><CheckCircle2 size={20} /><span>{message}</span><button aria-label="Đóng thông báo" onClick={() => setMessage('')}><X size={16} /></button></div>}</ToastContext.Provider>;
}
export function PageHeader({ title, description, action, back, eyebrow = 'QUẢN LÝ ĐÀO TẠO' }) {
  useEffect(() => { document.title = `${title} | Learnspace Admin`; }, [title]);
  return <div className="page-header">{back && <Link className="back-link" to={back.to}><ArrowLeft size={14} />{back.label}</Link>}<div className="page-heading-row"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{description && <p>{description}</p>}</div>{action}</div></div>;
}
export function StateView({ loading, error, retry, empty, title, children }) {
  if (loading) return <div className="state-view" role="status"><LoaderCircle className="spin" size={26} /><strong>Đang tải dữ liệu…</strong><span>Vui lòng chờ trong giây lát.</span></div>;
  if (error) return <div className="state-view error-state" role="alert"><CircleAlert size={30} /><strong>Không tải được dữ liệu</strong><span>{error}</span>{retry && <button className="btn secondary" onClick={retry}>Thử lại</button>}</div>;
  if (empty) return <div className="state-view"><Search size={30} /><strong>{title || 'Không có kết quả phù hợp'}</strong><span>Thử thay đổi từ khóa hoặc bộ lọc của bạn.</span></div>;
  return children;
}
export function StatusBadge({ course }) { return <span className={`status-badge ${course.deleted_at ? 'deleted' : course.status === 'inactive' ? 'inactive' : 'active'}`}><i />{course.deleted_at ? 'Trong thùng rác' : course.status === 'inactive' ? 'Đóng' : 'Mở'}</span>; }
export function ScoreBadge({ score }) { return <span className={`score-badge ${score < 5 ? 'low' : score < 8 ? 'mid' : 'high'}`}>{new Intl.NumberFormat('vi-VN', { maximumFractionDigits: 2 }).format(score)}<small> / 10</small></span>; }
export function SearchBox({ placeholder }) {
  const [params, setParams] = useSearchParams();
  const [value, setValue] = useState(params.get('q') || '');
  useEffect(() => { setValue(params.get('q') || ''); }, [params]);
  return <form className="search-box" onSubmit={(event) => { event.preventDefault(); const next = new URLSearchParams(params); if (value.trim()) next.set('q', value.trim()); else next.delete('q'); next.delete('page'); setParams(next); }}><Search size={16} /><input type="search" aria-label="Tìm kiếm" maxLength={100} placeholder={placeholder} value={value} onChange={(event) => setValue(event.target.value)} /><button type="submit">Tìm kiếm</button></form>;
}
export function Pagination({ page, pages, total, limit = 10 }) {
  const [params, setParams] = useSearchParams();
  function goto(value) { const next = new URLSearchParams(params); next.set('page', String(value)); setParams(next); }
  return <div className="pagination"><span>{total ? `${(page - 1) * limit + 1}–${Math.min(page * limit, total)}` : '0'} trên {total} kết quả</span><div><button aria-label="Trang trước" disabled={page <= 1} onClick={() => goto(page - 1)}><ChevronLeft size={16} /></button><span>Trang {page} / {Math.max(1, pages)}</span><button aria-label="Trang sau" disabled={page >= pages} onClick={() => goto(page + 1)}><ChevronRight size={16} /></button></div></div>;
}
export function FormError({ message }) { return message ? <div className="form-error" role="alert"><CircleAlert size={17} />{message}</div> : null; }
export function RouteScroll() { const { pathname } = useLocation(); useEffect(() => { window.scrollTo(0, 0); }, [pathname]); return null; }
export function TextLink({ to, children }) { return <Link className="text-link" to={to}>{children}<ArrowRight size={14} /></Link>; }
export function usePage() { const [params] = useSearchParams(); const value = Number(params.get('page') || 1); return Number.isInteger(value) && value > 0 ? value : 1; }
