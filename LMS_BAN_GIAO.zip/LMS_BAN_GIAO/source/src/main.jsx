import React from 'react';
import { createRoot } from 'react-dom/client';
import Module2 from './Module2.jsx';
import './styles.css';

createRoot(document.getElementById('root')).render(<React.StrictMode><Module2 /></React.StrictMode>);
