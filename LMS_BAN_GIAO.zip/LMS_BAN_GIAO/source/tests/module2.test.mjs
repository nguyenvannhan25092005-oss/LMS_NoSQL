import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { randomUUID } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { MongoClient } from 'mongodb';
import { createApp } from '../server/app.js';
import { config } from '../server/config.js';
import { ensureIndexes } from '../server/database.js';
import { courses } from '../scripts/sample-data.mjs';

// Database riêng, tạo tên ngẫu nhiên; tuyệt đối không drop DB_NAME của ứng dụng.
const testDbName = `lms_module2_test_${randomUUID().replaceAll('-', '')}`;
const client = new MongoClient(config.uri, { serverSelectionTimeoutMS: 5000 });
let db, server, base;
before(async () => {
  await client.connect();
  db = client.db(testDbName);
  await db.collection('courses').createIndex({ course_id: 1 }, { unique: true });
  await db.collection('courses').insertMany(courses.map((course) => ({ ...course })));
  await db.collection('students').createIndex({ student_id: 1 }, { unique: true });
  await db.collection('students').insertMany([
    { student_id: 'SV_TEST', full_name: 'Sinh viên kiểm thử', class_name: 'TEST', email: 'test@example.edu.vn', grades: [] },
    { student_id: 'SV_RACE', full_name: 'Kiểm thử đồng thời', grades: [] },
    { student_id: 'SV_NO_ARRAY', full_name: 'Chưa có mảng grades' },
  ]);
  server = createApp(db, { serveFrontend: false }).listen(0, '127.0.0.1');
  await once(server, 'listening');
  base = `http://127.0.0.1:${server.address().port}/api`;
});
after(async () => {
  if (server) await new Promise((resolve) => server.close(resolve));
  if (db && /^lms_module2_test_[a-f0-9]{32}$/.test(testDbName)) await db.dropDatabase();
  await client.close();
});

async function call(path, method = 'GET', body) {
  const response = await fetch(`${base}${path}`, {
    method,
    ...(body !== undefined ? { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {}),
  });
  return { status: response.status, body: await response.json() };
}
const post = (score, extra = {}) => call('/grades', 'POST', { student_id: 'SV_TEST', course_id: 'MH001', score, ...extra });

test('Health kết nối MongoDB thật', async () => {
  const result = await call('/health');
  assert.equal(result.status, 200);
  assert.equal(result.body.data.database, testDbName);
});
test('Danh mục có 5 môn, mã chuỗi và tín chỉ', async () => {
  const result = await call('/courses');
  assert.equal(result.status, 200);
  assert.equal(result.body.data.length, 5);
  assert.equal(result.body.data[0].course_id, 'MH001');
  assert.ok(result.body.data.every((course) => Number.isInteger(course.credits)));
});
test('Sinh viên không có điểm trả mảng rỗng; không lộ email hoặc trường tài khoản', async () => {
  const { body } = await call('/module2/students/SV_TEST');
  assert.deepEqual(body.data.grades, []);
  assert.equal(body.data.email, undefined);
});
for (const score of [-0.1, 10.1, null, '', '8', true, {}, []]) {
  test(`Từ chối điểm không hợp lệ: ${JSON.stringify(score)}`, async () => {
    const result = await post(score);
    assert.equal(result.status, 400);
    assert.equal(result.body.error.code, 'INVALID_SCORE');
  });
}
test('Từ chối thiếu mã, mã dạng object và điểm bị thiếu', async () => {
  assert.equal((await post(8, { student_id: '' })).status, 400);
  assert.equal((await post(8, { student_id: { $ne: null } })).status, 400);
  assert.equal((await post(8, { course_id: ['MH001'] })).status, 400);
  assert.equal((await call('/grades', 'POST', { student_id: 'SV_TEST', course_id: 'MH001' })).status, 400);
});
test('Từ chối sinh viên và môn học không tồn tại', async () => {
  assert.equal((await post(8, { student_id: 'NO_SUCH_STUDENT' })).body.error.code, 'STUDENT_NOT_FOUND');
  assert.equal((await post(8, { course_id: 'NO_SUCH_COURSE' })).body.error.code, 'COURSE_NOT_FOUND');
});
test('Nhập điểm 0; tên và tín chỉ lấy từ courses, không tin client', async () => {
  const result = await post(0, { course_name: 'Tên giả', credits: 999 });
  assert.equal(result.status, 201);
  assert.deepEqual(result.body.data.grade, { ...courses[0], score: 0 });
});
test('Trùng môn trả 409 và không thêm phần tử', async () => {
  assert.equal((await post(9)).status, 409);
  const student = await db.collection('students').findOne({ student_id: 'SV_TEST' });
  assert.equal(student.grades.length, 1);
  assert.equal(student.grades[0].score, 0);
});
test('Nhập môn khác rồi sửa điểm 10, bảo toàn hồ sơ và điểm môn khác', async () => {
  assert.equal((await post(6.25, { course_id: 'MH002' })).status, 201);
  const before = await db.collection('students').findOne({ student_id: 'SV_TEST' });
  assert.equal((await call('/grades/SV_TEST/MH001', 'PUT', { score: 10 })).status, 200);
  const after = await db.collection('students').findOne({ student_id: 'SV_TEST' });
  assert.deepEqual(after, { ...before, grades: [{ ...before.grades[0], score: 10 }, before.grades[1]] });
  assert.equal((await call('/grades/SV_TEST/MH001', 'PUT', { score: 10 })).status, 200);
});
test('PUT không tự tạo điểm và từ chối điểm không hợp lệ', async () => {
  assert.equal((await call('/grades/SV_TEST/MH005', 'PUT', { score: 8 })).body.error.code, 'GRADE_NOT_FOUND');
  assert.equal((await call('/grades/SV_TEST/MH001', 'PUT', { score: -1 })).status, 400);
  assert.equal((await call('/grades/NONE/MH001', 'PUT', { score: 8 })).body.error.code, 'STUDENT_NOT_FOUND');
});
test('20 yêu cầu đồng thời chỉ tạo đúng 1 điểm', async () => {
  const results = await Promise.all(Array.from({ length: 20 }, () => post(8, { student_id: 'SV_RACE' })));
  assert.equal(results.filter((result) => result.status === 201).length, 1);
  assert.equal(results.filter((result) => result.status === 409).length, 19);
  assert.equal((await db.collection('students').findOne({ student_id: 'SV_RACE' })).grades.length, 1);
});
test('Hỗ trợ hồ sơ chưa có grades; phát hiện grades sai schema', async () => {
  assert.equal((await post(5, { student_id: 'SV_NO_ARRAY' })).status, 201);
  await db.collection('students').insertOne({ student_id: 'SV_BAD', grades: {} });
  assert.equal((await post(5, { student_id: 'SV_BAD' })).body.error.code, 'INVALID_GRADES_DATA');
});
test('Không cho môn học có tín chỉ sai schema ghi điểm', async () => {
  await db.collection('courses').insertOne({ course_id: 'BAD', course_name: 'Lỗi', credits: -3 });
  assert.equal((await post(5, { course_id: 'BAD' })).body.error.code, 'INVALID_COURSE_DATA');
});
test('Luồng liên module: dữ liệu ghi điểm dùng được ngay cho Aggregation GPA của người 3', async () => {
  const [result] = await db.collection('students').aggregate([
    { $match: { student_id: 'SV_TEST' } },
    { $unwind: '$grades' },
    { $group: { _id: '$student_id', weighted: { $sum: { $multiply: ['$grades.score', '$grades.credits'] } }, credits: { $sum: '$grades.credits' } } },
    { $project: { _id: 0, gpa: { $divide: ['$weighted', '$credits'] } } },
  ]).toArray();
  assert.equal(result.gpa, (10 * 3 + 6.25 * 3) / 6);
});
test('Seed chạy lại không ghi đè hồ sơ và điểm đã lưu', async () => {
  const runSeed = () => spawnSync(process.execPath, ['scripts/seed.mjs'], {
    cwd: new URL('..', import.meta.url), env: { ...process.env, DB_NAME: testDbName }, encoding: 'utf8',
  });
  const first = runSeed();
  assert.equal(first.status, 0, first.stderr);
  await db.collection('students').updateOne({ student_id: 'SV001' }, { $set: { full_name: 'Tên do người 1 sửa', 'grades.0.score': 9.75 } });
  const snapshot = await db.collection('students').findOne({ student_id: 'SV001' });
  const second = runSeed();
  assert.equal(second.status, 0, second.stderr);
  assert.deepEqual(await db.collection('students').findOne({ student_id: 'SV001' }), snapshot);
});
test('API không tồn tại và JSON hỏng trả lỗi có cấu trúc', async () => {
  assert.equal((await call('/unknown')).status, 404);
  const response = await fetch(`${base}/grades`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{bad' });
  assert.equal(response.status, 400);
  assert.equal((await response.json()).error.code, 'INVALID_JSON');
});

test('Thêm môn, đọc chi tiết, từ chối trùng mã kể cả gửi đồng thời', async () => {
  const body = { course_id: 'MH_CRUD', course_name: 'Môn quản trị', credits: 3, status: 'active' };
  const results = await Promise.all(Array.from({ length: 12 }, () => call('/courses', 'POST', body)));
  assert.equal(results.filter((result) => result.status === 201).length, 1);
  assert.equal(results.filter((result) => result.status === 409).length, 11);
  const detail = await call('/courses/MH_CRUD');
  assert.equal(detail.status, 200);
  assert.equal(detail.body.data.course_name, body.course_name);
  assert.equal(detail.body.data.grade_count, 0);
});

test('Kiểm tra dữ liệu môn: tên rỗng, tín chỉ sai, mã và trạng thái sai', async () => {
  for (const fields of [
    { course_name: '' }, { course_name: ' ' }, { credits: 0 }, { credits: 31 }, { credits: 1.5 },
    { credits: '3' }, { course_id: 'Mã có khoảng trắng' }, { status: 'invalid' },
  ]) {
    assert.equal((await call('/courses', 'POST', { course_id: 'MH_INVALID', course_name: 'Hợp lệ', credits: 3, ...fields })).status, 400);
  }
  assert.equal((await call('/courses/MH_MISSING')).status, 404);
  assert.equal((await call('/courses/MH_MISSING', 'PUT', { course_name: 'Test', credits: 3 })).status, 404);
});

test('Sửa danh mục không đổi lịch sử điểm; sửa điểm tiếp tục giữ snapshot', async () => {
  assert.equal((await post(7.5, { course_id: 'MH_CRUD' })).status, 201);
  const saved = (await db.collection('students').findOne({ student_id: 'SV_TEST' })).grades.find((grade) => grade.course_id === 'MH_CRUD');
  assert.equal((await call('/courses/MH_CRUD', 'PUT', { course_name: 'Tên môn sau chỉnh sửa', credits: 4, status: 'active' })).status, 200);
  const updated = await call('/grades/SV_TEST/MH_CRUD', 'PUT', { score: 8.5 });
  assert.deepEqual(updated.body.data.grade, { ...saved, score: 8.5 });
  const detail = await call('/courses/MH_CRUD');
  assert.equal(detail.body.data.credits, 4);
  assert.equal(detail.body.data.grade_count, 1);
});

test('Xóa môn vào thùng rác, bảo toàn điểm, không nhận điểm mới', async () => {
  const snapshot = await db.collection('students').findOne({ student_id: 'SV_TEST' });
  assert.equal((await call('/courses/MH_CRUD', 'DELETE')).status, 200);
  assert.deepEqual(await db.collection('students').findOne({ student_id: 'SV_TEST' }), snapshot);
  assert.equal((await call('/courses')).body.data.some((course) => course.course_id === 'MH_CRUD'), false);
  assert.equal((await call('/courses?trash=true')).body.data.some((course) => course.course_id === 'MH_CRUD'), true);
  assert.equal((await post(5, { course_id: 'MH_CRUD', student_id: 'SV_RACE' })).body.error.code, 'COURSE_INACTIVE');
  assert.equal((await call('/grades/SV_TEST/MH_CRUD', 'PUT', { score: 9 })).status, 200);
  assert.equal((await call('/courses/MH_CRUD', 'DELETE')).status, 404);
  assert.equal((await call('/courses', 'POST', { course_id: 'MH_CRUD', course_name: 'Trùng', credits: 2 })).status, 409);
});

test('Khôi phục môn ở trạng thái inactive, kích hoạt lại mới nhận điểm mới', async () => {
  assert.equal((await call('/courses/MH_CRUD/restore', 'POST')).status, 200);
  assert.equal((await call('/courses/MH_CRUD')).body.data.status, 'inactive');
  assert.equal((await post(5, { course_id: 'MH_CRUD', student_id: 'SV_RACE' })).status, 409);
  assert.equal((await call('/courses/MH_CRUD', 'PUT', { course_name: 'Tên môn sau chỉnh sửa', credits: 4, status: 'active' })).status, 200);
  const result = await post(5, { course_id: 'MH_CRUD', student_id: 'SV_RACE' });
  assert.equal(result.status, 201);
  assert.equal(result.body.data.grade.credits, 4);
  assert.equal((await call('/courses/MH_CRUD/restore', 'POST')).status, 404);
});

test('Xóa đúng một bản điểm, bảo toàn hồ sơ và các môn khác', async () => {
  const before = await db.collection('students').findOne({ student_id: 'SV_TEST' });
  assert.equal((await call('/grades/SV_TEST/MH_CRUD', 'DELETE')).status, 200);
  const after = await db.collection('students').findOne({ student_id: 'SV_TEST' });
  assert.deepEqual(after, { ...before, grades: before.grades.filter((grade) => grade.course_id !== 'MH_CRUD') });
  assert.equal((await call('/grades/SV_TEST/MH_CRUD', 'DELETE')).status, 404);
  assert.equal((await call('/grades/SV_MISSING/MH001', 'DELETE')).status, 404);
});

test('Tìm kiếm và phân trang điểm chính xác, tìm kiếm regex được escape', async () => {
  const found = await call('/module2/grades?q=SV_TEST&limit=1');
  assert.equal(found.status, 200);
  assert.equal(found.body.data.length, 1);
  assert.equal(found.body.pagination.total, 2);
  assert.equal(found.body.pagination.pages, 2);
  const next = await call('/module2/grades?q=SV_TEST&limit=1&page=2');
  assert.notEqual(next.body.data[0].grade.course_id, found.body.data[0].grade.course_id);
  const filtered = await call('/module2/grades?q=SV_TEST&course_id=MH002');
  assert.equal(filtered.body.data.length, 1);
  assert.equal(filtered.body.data[0].grade.course_id, 'MH002');
  assert.equal((await call('/module2/grades?q=%5B')).body.data.length, 0);
});

test('Danh sách sinh viên có phân trang, không lộ trường email và tài khoản', async () => {
  const result = await call('/module2/students?q=SV001&limit=5');
  assert.equal(result.status, 200);
  assert.equal(result.body.data.length, 1);
  assert.equal(typeof result.body.data[0].grade_count, 'number');
  assert.equal(result.body.data[0].email, undefined);
  assert.equal((await call('/module2/students?limit=1&page=999')).body.data.length, 0);
});

test('Từ chối phân trang và tìm kiếm sai kiểu', async () => {
  for (const path of ['/module2/students?page=0', '/module2/grades?limit=101', '/module2/grades?q=a&q=b', '/module2/grades?course_id=x&course_id=y']) {
    assert.equal((await call(path)).status, 400, path);
  }
});

test('Dashboard lấy số liệu từ MongoDB và xử lý database trống', async () => {
  const result = await call('/module2/dashboard');
  assert.equal(result.status, 200);
  assert.equal(result.body.data.studentCount, await db.collection('students').countDocuments());
  assert.ok(result.body.data.gradeStats.count > 0);
  assert.ok(Array.isArray(result.body.data.courseCoverage));
  const emptyName = `lms_module2_test_${randomUUID().replaceAll('-', '')}`;
  const emptyServer = createApp(client.db(emptyName), { serveFrontend: false }).listen(0, '127.0.0.1');
  await once(emptyServer, 'listening');
  try {
    const response = await fetch(`http://127.0.0.1:${emptyServer.address().port}/api/module2/dashboard`);
    const body = await response.json();
    assert.equal(body.data.studentCount, 0);
    assert.deepEqual(body.data.gradeStats, { count: 0, excellent: 0, good: 0, pass: 0, fail: 0 });
  } finally { await new Promise((resolve) => emptyServer.close(resolve)); await client.db(emptyName).dropDatabase(); }
});

test('Các trang con hỗ trợ truy cập trực tiếp, tài nguyên và API không tồn tại trả 404', async () => {
  const webServer = createApp(db).listen(0, '127.0.0.1');
  await once(webServer, 'listening');
  const url = `http://127.0.0.1:${webServer.address().port}`;
  try {
    for (const path of ['/dashboard', '/courses/new', '/courses/MH001/edit', '/grades/SV001/MH001/delete']) {
      const response = await fetch(`${url}${path}`);
      assert.equal(response.status, 200);
      assert.match(await response.text(), /<div id="root"><\/div>/);
    }
    assert.equal((await fetch(`${url}/assets/missing.js`)).status, 404);
    assert.equal((await fetch(`${url}/api/missing`)).status, 404);
  } finally { await new Promise((resolve) => webServer.close(resolve)); }
});

test('Khởi tạo index không tự thêm dữ liệu mẫu và có thể chạy lại', async () => {
  const emptyName = `lms_module2_test_${randomUUID().replaceAll('-', '')}`;
  const emptyDb = client.db(emptyName);
  try {
    await ensureIndexes(emptyDb);
    await ensureIndexes(emptyDb);
    assert.equal(await emptyDb.collection('courses').countDocuments(), 0);
    assert.equal(await emptyDb.collection('students').countDocuments(), 0);
    assert.ok((await emptyDb.collection('courses').listIndexes().toArray()).some((index) => index.key.course_id === 1 && index.unique));
    assert.ok((await emptyDb.collection('students').listIndexes().toArray()).some((index) => index.key.student_id === 1 && index.unique));
  } finally { await emptyDb.dropDatabase(); }
});
