@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Can cai Node.js 22.12+ truoc khi chay.
  pause
  exit /b 1
)
call npm.cmd ci
if errorlevel 1 goto :failed
echo Mo http://127.0.0.1:3000 sau khi hien thong bao khoi dong.
call npm.cmd start
if errorlevel 1 goto :failed
exit /b 0
:failed
echo Khong chay duoc. Kiem tra MongoDB Server hoac xem README.md.
pause
exit /b 1
