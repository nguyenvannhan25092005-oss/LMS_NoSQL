# Mã nguồn LMS

Chạy `npm.cmd ci` rồi `npm.cmd start`. Website: http://127.0.0.1:3000/dashboard.

Cấu hình mặc định: MongoDB `mongodb://127.0.0.1:27017`, database `lms_tuan1_module2`. Copy `.env.example` thành `.env` để thay cấu hình.

| Lệnh | Công dụng |
| --- | --- |
| npm.cmd start | Build giao diện và chạy website |
| npm.cmd run dev | Phát triển: giao diện 5173, API 3000 |
| npm.cmd run db:check | Kiểm tra kết nối, chỉ đọc dữ liệu |
| npm.cmd run db:import | Nhập bản xuất từ ../database vào database trống |
| npm.cmd run db:export -- D:\ban-sao-moi | Xuất database vào một thư mục mới |
| npm.cmd test | Kiểm thử nghiệp vụ với database tạm riêng |
| npm.cmd run seed | Tùy chọn nạp dữ liệu mẫu từ mongo/seed |

`src/` là frontend; `server/` là backend; `scripts/` là lệnh hỗ trợ; `tests/` là bộ kiểm thử; `mongo/` mô tả schema và dữ liệu mẫu tùy chọn. Website không tự nhập database hoặc seed khi khởi động.

Hướng dẫn bàn giao và nhập database ở README.md tại thư mục cha.
