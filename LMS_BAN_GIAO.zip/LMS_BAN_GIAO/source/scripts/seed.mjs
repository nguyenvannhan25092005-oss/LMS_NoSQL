import { MongoClient } from 'mongodb';
import { config } from '../server/config.js';
import { courses, students } from './sample-data.mjs';
import { ensureIndexes } from '../server/database.js';

const client = new MongoClient(config.uri, { serverSelectionTimeoutMS: 5000 });
try {
  await client.connect();
  const db = client.db(config.dbName);
  await ensureIndexes(db);
  // Chỉ thêm bản ghi CHƯA CÓ. Chạy lại không ghi đè hồ sơ hay điểm của nhóm.
  for (const course of courses) {
    await db.collection('courses').updateOne({ course_id: course.course_id }, { $setOnInsert: course }, { upsert: true });
  }
  if (!process.argv.includes('--courses-only')) {
    for (const student of students) {
      await db.collection('students').updateOne({ student_id: student.student_id }, { $setOnInsert: student }, { upsert: true });
    }
  }
  console.log(`Đã chuẩn bị database ${config.dbName}.`);
  console.log(`Môn học: ${await db.collection('courses').countDocuments()}; sinh viên: ${await db.collection('students').countDocuments()}.`);
  console.log('Dữ liệu đã tồn tại được giữ nguyên. Mở Compass rồi Refresh để xem.');
} catch (err) {
  console.error('Seed thất bại:', err.message);
  process.exitCode = 1;
} finally {
  await client.close();
}
