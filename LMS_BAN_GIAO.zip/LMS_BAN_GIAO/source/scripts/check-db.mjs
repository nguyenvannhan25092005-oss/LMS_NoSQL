import { MongoClient } from 'mongodb';
import { config } from '../server/config.js';

const client = new MongoClient(config.uri, { serverSelectionTimeoutMS: 5000 });
try {
  await client.connect();
  const db = client.db(config.dbName);
  await db.command({ ping: 1 });
  const [courses, students] = await Promise.all([
    db.collection('courses').countDocuments(), db.collection('students').countDocuments(),
  ]);
  console.log('Kết nối MongoDB thành công.');
  console.log(`Database: ${db.databaseName}`);
  console.log(`Dữ liệu đọc trực tiếp: ${courses} môn học; ${students} sinh viên.`);
  console.log('Lệnh này chỉ kiểm tra kết nối, không tạo hoặc sửa dữ liệu.');
} catch (error) {
  console.error(`Không kết nối được MongoDB (${error.name}).`);
  console.error('Kiểm tra dịch vụ MongoDB Server và MONGODB_URI trong .env.');
  console.error('Compass phải dùng đúng cùng host và cổng với MongoDB Server.');
  process.exitCode = 1;
} finally {
  await client.close();
}
