import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { BSON, MongoClient } from 'mongodb';
import { config } from '../server/config.js';
import { ensureIndexes } from '../server/database.js';

const input = path.resolve(process.argv[2] || fileURLToPath(new URL('../../database/', import.meta.url)));
const client = new MongoClient(config.uri, { serverSelectionTimeoutMS: 5000 });
try {
  if (['admin', 'local', 'config'].includes(config.dbName)) throw new Error('Không nhập vào database hệ thống.');
  const manifest = BSON.EJSON.parse(await readFile(path.join(input, 'manifest.json'), 'utf8'));
  if (manifest.format !== 'mongodb-extended-json' || manifest.version !== 1 || !Array.isArray(manifest.collections)) throw new Error('Định dạng bản xuất không hợp lệ.');
  const prepared = [];
  const names = new Set();
  for (const item of manifest.collections) {
    if (typeof item.name !== 'string' || !item.name || item.name.startsWith('system.') || names.has(item.name)) throw new Error('Tên collection không hợp lệ hoặc trùng.');
    if (typeof item.file !== 'string' || path.basename(item.file) !== item.file) throw new Error('Đường dẫn dữ liệu không hợp lệ.');
    names.add(item.name);
    const documents = BSON.EJSON.parse(await readFile(path.join(input, item.file), 'utf8'), { relaxed: false });
    if (!Array.isArray(documents) || documents.length !== item.count) throw new Error(`Số bản ghi không khớp: ${item.name}`);
    prepared.push({ ...item, documents });
  }
  await client.connect();
  const db = client.db(config.dbName);
  const existing = await db.listCollections({}, { nameOnly: true }).toArray();
  for (const item of existing) {
    if (item.type === 'view' || await db.collection(item.name).countDocuments() > 0) throw new Error(`Database ${db.databaseName} đã có dữ liệu. Chọn DB_NAME mới trong .env để tránh ghi đè.`);
  }
  const indexFields = ['key', 'name', 'unique', 'sparse', 'partialFilterExpression', 'expireAfterSeconds', 'collation', 'hidden', 'weights', 'default_language', 'language_override', 'textIndexVersion', '2dsphereIndexVersion'];
  for (const item of prepared) {
    if (!existing.some((collection) => collection.name === item.name)) await db.createCollection(item.name, item.options || {});
    const collection = db.collection(item.name);
    if (item.documents.length) await collection.insertMany(item.documents);
    const indexes = (item.indexes || []).filter((index) => index.name !== '_id_')
      .map((index) => Object.fromEntries(indexFields.filter((key) => key in index).map((key) => [key, index[key]])));
    if (indexes.length) await collection.createIndexes(indexes);
  }
  await ensureIndexes(db);
  console.log(`Đã nhập ${prepared.length} collection vào database ${db.databaseName}.`);
} catch (error) {
  console.error('Nhập database thất bại:', error.message);
  console.error('Không xóa hay ghi đè database hiện có. Nếu quá trình nhập bị gián đoạn, kiểm tra database đích trước khi thử lại.');
  process.exitCode = 1;
} finally { await client.close(); }
