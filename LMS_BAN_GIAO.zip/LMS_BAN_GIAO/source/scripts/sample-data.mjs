import { readFile } from 'node:fs/promises';

// Chỉ công cụ seed và kiểm thử sử dụng module này.
// Backend và React không import dữ liệu mẫu, luôn truy vấn MongoDB.
export const courses = JSON.parse(await readFile(new URL('../mongo/seed/courses.json', import.meta.url), 'utf8'));
export const students = JSON.parse(await readFile(new URL('../mongo/seed/students.json', import.meta.url), 'utf8'));
