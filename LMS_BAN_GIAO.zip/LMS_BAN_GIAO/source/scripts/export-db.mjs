import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { BSON, MongoClient } from 'mongodb';
import { config } from '../server/config.js';

const output = path.resolve(process.argv[2] || fileURLToPath(new URL('../../database/', import.meta.url)));
const client = new MongoClient(config.uri, { serverSelectionTimeoutMS: 5000 });
try {
  await client.connect();
  const db = client.db(config.dbName);
  const collections = await db.listCollections({}, { nameOnly: false }).toArray();
  const manifest = { format: 'mongodb-extended-json', version: 1, database: db.databaseName, exported_at: new Date().toISOString(), collections: [] };
  await mkdir(output, { recursive: true });
  for (const item of collections.sort((a, b) => a.name.localeCompare(b.name))) {
    if (item.name.startsWith('system.')) continue;
    if (item.type !== 'collection') throw new Error(`Không hỗ trợ xuất đối tượng ${item.type}: ${item.name}`);
    const collection = db.collection(item.name);
    const documents = await collection.find({}).sort({ _id: 1 }).toArray();
    const filename = `${encodeURIComponent(item.name)}.json`;
    await writeFile(path.join(output, filename), BSON.EJSON.stringify(documents, null, 2, { relaxed: false }) + '\n', { flag: 'wx' });
    manifest.collections.push({ name: item.name, file: filename, count: documents.length, options: item.options || {}, indexes: await collection.listIndexes().toArray() });
  }
  await writeFile(path.join(output, 'manifest.json'), BSON.EJSON.stringify(manifest, null, 2, { relaxed: false }) + '\n', { flag: 'wx' });
  console.log(`Đã xuất ${manifest.collections.length} collection từ ${db.databaseName} vào ${output}.`);
} catch (error) {
  console.error('Xuất database thất bại:', error.message);
  console.error('Chọn thư mục đầu ra mới nếu bản xuất đã tồn tại.');
  process.exitCode = 1;
} finally { await client.close(); }
