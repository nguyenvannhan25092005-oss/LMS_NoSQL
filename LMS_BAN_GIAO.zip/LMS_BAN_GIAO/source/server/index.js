import { MongoClient } from 'mongodb';
import { config } from './config.js';
import { createApp } from './app.js';
import { ensureIndexes } from './database.js';

const client = new MongoClient(config.uri, { serverSelectionTimeoutMS: 5000 });
try {
  await client.connect();
  const db = client.db(config.dbName);
  await db.command({ ping: 1 });
  await ensureIndexes(db);
  const server = createApp(db).listen(config.port, config.host, () => {
    console.log(`LMS nội dung 2: http://${config.host}:${config.port}`);
    console.log(`Database: ${config.dbName}`);
  });
  server.on('error', async (err) => {
    console.error(err.code === 'EADDRINUSE' ? `Cổng ${config.port} đang được sử dụng.` : err.message);
    await client.close();
    process.exitCode = 1;
  });
  for (const signal of ['SIGINT', 'SIGTERM']) {
    process.on(signal, () => server.close(async () => { await client.close(); process.exit(0); }));
  }
} catch (err) {
  console.error('Không khởi động được. Kiểm tra MongoDB Server và MONGODB_URI trong .env.');
  console.error(err.name);
  await client.close();
  process.exitCode = 1;
}
