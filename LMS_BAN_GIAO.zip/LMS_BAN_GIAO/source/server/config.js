import 'dotenv/config';

export const config = {
  uri: process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017',
  dbName: process.env.DB_NAME || 'lms_tuan1_module2',
  port: Number(process.env.PORT || 3000),
  host: process.env.HOST || '127.0.0.1',
};
