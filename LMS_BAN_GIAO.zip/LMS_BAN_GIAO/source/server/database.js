// Chuẩn bị ràng buộc dữ liệu; không thêm sinh viên, môn học hoặc điểm mẫu.
async function ensureUniqueIndex(collection, field, name) {
  let indexes = [];
  try { indexes = await collection.listIndexes().toArray(); }
  catch (error) { if (error.code !== 26) throw error; }
  const existing = indexes.find((index) => Object.keys(index.key).length === 1
    && index.key[field] === 1 && index.unique && !index.sparse && !index.partialFilterExpression);
  if (!existing) await collection.createIndex({ [field]: 1 }, { unique: true, name });
}

export async function ensureIndexes(db) {
  await ensureUniqueIndex(db.collection('courses'), 'course_id', 'uniq_course_id');
  await ensureUniqueIndex(db.collection('students'), 'student_id', 'uniq_student_id');
}
