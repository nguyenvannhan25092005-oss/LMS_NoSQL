
import express from 'express';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Module 1 - Quản lý sinh viên và tài khoản
import { createModule1Router } from './module1.js';

// Module 2 - Quản lý môn học và nhập điểm
import { apiErrorHandler, createModule2Router } from './module2.js';

const dist = fileURLToPath(new URL('../dist/', import.meta.url));

export function createApp(db, { serveFrontend = true } = {}) {
  const app = express();

  app.disable('x-powered-by');
  app.use(express.json({ limit: '16kb' }));

  // Kiểm tra kết nối MongoDB
  app.get('/api/health', async (_req, res) => {
    await db.command({ ping: 1 });

    res.json({
      data: {
        status: 'ok',
        database: db.databaseName
      }
    });
  });

  // Đăng ký Module 1
  app.use('/api', createModule1Router(db));

  // Giữ nguyên Module 2 của bạn trong nhóm
  app.use('/api', createModule2Router(db));

  // Xử lý API không tồn tại
  app.use('/api', (_req, res) =>
    res.status(404).json({
      error: {
        code: 'NOT_FOUND',
        message: 'API không tồn tại.'
      }
    })
  );

  // Phục vụ giao diện React
  if (serveFrontend && existsSync(path.join(dist, 'index.html'))) {
    app.use(express.static(dist));

    app.get('/{*path}', (req, res) => {
      if (path.extname(req.path)) {
        return res.sendStatus(404);
      }

      return res.sendFile(path.join(dist, 'index.html'));
    });
  }

  app.use(apiErrorHandler);

  return app;
}
