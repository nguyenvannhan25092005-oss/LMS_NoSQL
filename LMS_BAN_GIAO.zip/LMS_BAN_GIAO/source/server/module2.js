import { Router } from 'express';

export class ApiError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

function identifier(value, field) {
  if (typeof value !== 'string' || !value.trim() || value.trim().length > 64) {
    throw new ApiError(400, 'INVALID_ID', `${field} phải là chuỗi từ 1 đến 64 ký tự.`);
  }
  return value.trim();
}

function validScore(value) {
  // Không ép kiểu: null, chuỗi rỗng, boolean và object đều phải bị từ chối.
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 10) {
    throw new ApiError(400, 'INVALID_SCORE', 'Điểm phải là số trong khoảng từ 0 đến 10.');
  }
  return value;
}

async function courseSnapshot(db, courseId, score, { forNewGrade = false } = {}) {
  const course = await db.collection('courses').findOne({ course_id: courseId });
  if (!course) throw new ApiError(404, 'COURSE_NOT_FOUND', 'Không tìm thấy mã môn học.');
  if (forNewGrade && (course.deleted_at || course.status === 'inactive')) {
    throw new ApiError(409, 'COURSE_INACTIVE', 'Môn học đã đóng. Chỉ được sửa điểm đã có.');
  }
  if (typeof course.course_name !== 'string' || !course.course_name.trim()
    || !Number.isInteger(course.credits) || course.credits <= 0) {
    throw new ApiError(409, 'INVALID_COURSE_DATA', 'Môn học thiếu tên hoặc số tín chỉ hợp lệ.');
  }
  // Luôn lấy tên và tín chỉ từ MongoDB, không tin dữ liệu client gửi lên.
  return { course_id: course.course_id, course_name: course.course_name, credits: course.credits, score };
}

async function requireStudent(db, studentId) {
  const student = await db.collection('students').findOne(
    { student_id: studentId },
    { projection: { _id: 0, student_id: 1, full_name: 1, class_name: 1, grades: 1 } },
  );
  if (!student) throw new ApiError(404, 'STUDENT_NOT_FOUND', 'Không tìm thấy mã sinh viên.');
  if (student.grades !== undefined && !Array.isArray(student.grades)) {
    throw new ApiError(409, 'INVALID_GRADES_DATA', 'Trường grades phải là một mảng. Hãy kiểm tra schema chung.');
  }
  return { ...student, grades: student.grades || [] };
}

// Mount bằng app.use('/api', createModule2Router(db)). Không sở hữu route /students của người 1/3.
export function createModule2Router(db) {
  const router = Router();
  const students = db.collection('students');

  router.get('/courses', async (req, res) => {
    const filter = req.query.trash === 'true' ? { deleted_at: { $exists: true } } : { deleted_at: { $exists: false } };
    const courses = await db.collection('courses').find(filter, { projection: { _id: 0 } })
      .sort({ course_id: 1 }).toArray();
    res.json({ data: courses });
  });

  router.get('/courses/:courseId', async (req, res) => {
    const course = await db.collection('courses').findOne(
      { course_id: identifier(req.params.courseId, 'Mã môn học') }, { projection: { _id: 0 } },
    );
    if (!course) throw new ApiError(404, 'COURSE_NOT_FOUND', 'Không tìm thấy môn học.');
    const grade_count = await students.countDocuments({ 'grades.course_id': course.course_id });
    res.json({ data: { ...course, grade_count } });
  });

  function courseFields(body) {
    if (typeof body?.course_name !== 'string' || !body.course_name.trim() || body.course_name.trim().length > 150) {
      throw new ApiError(400, 'INVALID_COURSE_NAME', 'Tên môn học phải có từ 1 đến 150 ký tự.');
    }
    if (!Number.isInteger(body.credits) || body.credits < 1 || body.credits > 30) {
      throw new ApiError(400, 'INVALID_CREDITS', 'Số tín chỉ phải là số nguyên từ 1 đến 30.');
    }
    const status = body.status ?? 'active';
    if (!['active', 'inactive'].includes(status)) throw new ApiError(400, 'INVALID_STATUS', 'Trạng thái môn học không hợp lệ.');
    return { course_name: body.course_name.trim(), credits: body.credits, status };
  }

  router.post('/courses', async (req, res) => {
    const course_id = identifier(req.body?.course_id, 'Mã môn học');
    if (!/^[A-Za-z0-9_-]+$/.test(course_id)) throw new ApiError(400, 'INVALID_ID', 'Mã môn chỉ gồm chữ, số, dấu gạch ngang và gạch dưới.');
    const course = { course_id, ...courseFields(req.body) };
    // Upsert kết hợp unique index course_id: không tạo mã môn trùng khi gửi đồng thời.
    const result = await db.collection('courses').updateOne({ course_id }, { $setOnInsert: course }, { upsert: true });
    if (!result.upsertedCount) throw new ApiError(409, 'COURSE_EXISTS', 'Mã môn đã tồn tại, kể cả trong thùng rác. Vui lòng dùng mã khác hoặc khôi phục môn.');
    res.status(201).json({ message: 'Đã thêm môn học.', data: course });
  });

  router.put('/courses/:courseId', async (req, res) => {
    const course_id = identifier(req.params.courseId, 'Mã môn học');
    const fields = courseFields(req.body);
    const result = await db.collection('courses').updateOne(
      { course_id, deleted_at: { $exists: false } }, { $set: fields },
    );
    if (!result.matchedCount) throw new ApiError(404, 'COURSE_NOT_FOUND', 'Môn không tồn tại hoặc đã ở trong thùng rác.');
    // Điểm đã lưu là snapshot, không ghi đè tín chỉ/tên trong lịch sử điểm của sinh viên.
    res.json({ message: 'Đã cập nhật môn học. Điểm đã ghi nhận được giữ nguyên.', data: { course_id, ...fields } });
  });

  router.delete('/courses/:courseId', async (req, res) => {
    const course_id = identifier(req.params.courseId, 'Mã môn học');
    const result = await db.collection('courses').updateOne(
      { course_id, deleted_at: { $exists: false } }, { $set: { deleted_at: new Date(), status: 'inactive' } },
    );
    if (!result.matchedCount) throw new ApiError(404, 'COURSE_NOT_FOUND', 'Môn không tồn tại hoặc đã ở trong thùng rác.');
    res.json({ message: 'Đã chuyển môn học vào thùng rác. Điểm sinh viên được giữ nguyên.' });
  });

  router.post('/courses/:courseId/restore', async (req, res) => {
    const course_id = identifier(req.params.courseId, 'Mã môn học');
    const result = await db.collection('courses').updateOne(
      { course_id, deleted_at: { $exists: true } }, { $unset: { deleted_at: '' }, $set: { status: 'inactive' } },
    );
    if (!result.matchedCount) throw new ApiError(404, 'COURSE_NOT_FOUND', 'Không tìm thấy môn trong thùng rác.');
    res.json({ message: 'Đã khôi phục môn ở trạng thái đóng. Bạn có thể sửa để mở lại.' });
  });

  const escaped = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  function pageOptions(query) {
    const page = Number(query.page ?? 1), limit = Number(query.limit ?? 10);
    if (!Number.isInteger(page) || page < 1 || page > 100000 || !Number.isInteger(limit) || limit < 1 || limit > 100) {
      throw new ApiError(400, 'INVALID_PAGINATION', 'Phân trang không hợp lệ.');
    }
    if (query.q !== undefined && (typeof query.q !== 'string' || query.q.length > 100)) throw new ApiError(400, 'INVALID_SEARCH', 'Từ khóa tìm kiếm tối đa 100 ký tự.');
    return { page, limit, q: query.q?.trim() || '' };
  }

  router.get('/module2/students', async (req, res) => {
    const { page, limit, q } = pageOptions(req.query);
    const match = q ? { $or: ['student_id', 'full_name', 'class_name'].map((field) => ({ [field]: { $regex: escaped(q), $options: 'i' } })) } : {};
    const [data, total] = await Promise.all([
      students.aggregate([
        { $match: match }, { $sort: { student_id: 1 } }, { $skip: (page - 1) * limit }, { $limit: limit },
        { $project: { _id: 0, student_id: 1, full_name: 1, class_name: 1, grade_count: { $size: { $cond: [{ $isArray: '$grades' }, '$grades', []] } } } },
      ]).toArray(), students.countDocuments(match),
    ]);
    res.json({ data, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
  });

  router.get('/module2/grades', async (req, res) => {
    const { page, limit, q } = pageOptions(req.query);
    const match = {};
    if (q) match.$or = ['student_id', 'full_name', 'grades.course_name', 'grades.course_id'].map((field) => ({ [field]: { $regex: escaped(q), $options: 'i' } }));
    if (req.query.course_id !== undefined) match['grades.course_id'] = identifier(req.query.course_id, 'Mã môn');
    const [result] = await students.aggregate([
      { $unwind: '$grades' }, { $match: match },
      { $sort: { student_id: 1, 'grades.course_id': 1 } },
      { $facet: {
        data: [{ $skip: (page - 1) * limit }, { $limit: limit }, { $project: { _id: 0, student_id: 1, full_name: 1, class_name: 1, grade: '$grades' } }],
        total: [{ $count: 'count' }],
      } },
    ]).toArray();
    const total = result.total[0]?.count || 0;
    res.json({ data: result.data, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
  });

  router.get('/module2/dashboard', async (_req, res) => {
    const [courseCount, activeCourses, studentCount, gradedStudents, gradeSummary, sample, courseCoverage] = await Promise.all([
      db.collection('courses').countDocuments({ deleted_at: { $exists: false } }),
      db.collection('courses').countDocuments({ deleted_at: { $exists: false }, status: { $ne: 'inactive' } }),
      students.countDocuments(), students.countDocuments({ 'grades.0': { $exists: true } }),
      students.aggregate([{ $unwind: '$grades' }, { $group: { _id: null, count: { $sum: 1 },
        excellent: { $sum: { $cond: [{ $gte: ['$grades.score', 8] }, 1, 0] } },
        good: { $sum: { $cond: [{ $and: [{ $gte: ['$grades.score', 6.5] }, { $lt: ['$grades.score', 8] }] }, 1, 0] } },
        pass: { $sum: { $cond: [{ $and: [{ $gte: ['$grades.score', 5] }, { $lt: ['$grades.score', 6.5] }] }, 1, 0] } },
        fail: { $sum: { $cond: [{ $lt: ['$grades.score', 5] }, 1, 0] } },
      } }]).toArray(),
      students.aggregate([{ $unwind: '$grades' }, { $sort: { student_id: 1, 'grades.course_id': 1 } }, { $limit: 5 }, { $project: { _id: 0, student_id: 1, full_name: 1, grade: '$grades' } }]).toArray(),
      students.aggregate([{ $unwind: '$grades' }, { $group: { _id: '$grades.course_id', count: { $sum: 1 }, course_name: { $first: '$grades.course_name' } } }, { $sort: { _id: 1 } }]).toArray(),
    ]);
    const { _id, ...gradeStats } = gradeSummary[0] || { count: 0, excellent: 0, good: 0, pass: 0, fail: 0 };
    res.json({ data: { courseCount, activeCourses, studentCount, gradedStudents, gradeStats, sample, courseCoverage } });
  });

  router.get('/module2/students/:studentId', async (req, res) => {
    const studentId = identifier(req.params.studentId, 'Mã sinh viên');
    res.json({ data: await requireStudent(db, studentId) });
  });

  router.post('/grades', async (req, res) => {
    const studentId = identifier(req.body?.student_id, 'Mã sinh viên');
    const courseId = identifier(req.body?.course_id, 'Mã môn học');
    const score = validScore(req.body?.score);
    const grade = await courseSnapshot(db, courseId, score, { forNewGrade: true });
    await requireStudent(db, studentId);

    // Kiểm tra không trùng và $push trong MỘT thao tác nguyên tử trên document.
    // Không dùng unique multikey index để chống trùng phần tử cùng một mảng.
    const result = await students.updateOne(
      { student_id: studentId, 'grades.course_id': { $ne: courseId } },
      { $push: { grades: grade } },
    );
    if (!result.matchedCount) {
      await requireStudent(db, studentId);
      throw new ApiError(409, 'GRADE_EXISTS', 'Sinh viên đã có điểm môn này. Hãy chọn cập nhật điểm.');
    }
    res.status(201).json({ message: 'Đã lưu điểm mới vào MongoDB.', data: { student_id: studentId, grade } });
  });

  router.put('/grades/:studentId/:courseId', async (req, res) => {
    const studentId = identifier(req.params.studentId, 'Mã sinh viên');
    const courseId = identifier(req.params.courseId, 'Mã môn học');
    const score = validScore(req.body?.score);
    const student = await requireStudent(db, studentId);
    const existing = student.grades.find((grade) => grade.course_id === courseId);
    if (!existing) throw new ApiError(404, 'GRADE_NOT_FOUND', 'Sinh viên chưa có điểm môn này. Hãy nhập điểm mới.');
    // Chỉnh điểm không thay đổi snapshot tín chỉ/tên của bản điểm lịch sử.
    const grade = { ...existing, score };
    const result = await students.updateOne(
      { student_id: studentId, 'grades.course_id': courseId },
      { $set: {
        'grades.$.score': grade.score,
      } },
    );
    if (!result.matchedCount) {
      await requireStudent(db, studentId);
      throw new ApiError(404, 'GRADE_NOT_FOUND', 'Sinh viên chưa có điểm môn này. Hãy nhập điểm mới.');
    }
    res.json({ message: 'Đã cập nhật điểm trong MongoDB.', data: { student_id: studentId, grade } });
  });

  router.delete('/grades/:studentId/:courseId', async (req, res) => {
    const student_id = identifier(req.params.studentId, 'Mã sinh viên');
    const course_id = identifier(req.params.courseId, 'Mã môn');
    await requireStudent(db, student_id);
    const result = await students.updateOne({ student_id, 'grades.course_id': course_id }, { $pull: { grades: { course_id } } });
    if (!result.matchedCount) throw new ApiError(404, 'GRADE_NOT_FOUND', 'Không tìm thấy điểm để xóa.');
    res.json({ message: 'Đã xóa điểm môn học của sinh viên.' });
  });
  return router;
}

// Đặt middleware này SAU TẤT CẢ router khi tích hợp.
export function apiErrorHandler(err, _req, res, _next) {
  if (err instanceof ApiError) return res.status(err.status).json({ error: { code: err.code, message: err.message } });
  if (err.code === 11000) return res.status(409).json({ error: { code: 'DUPLICATE_ID', message: 'Mã đã tồn tại. Vui lòng tải lại và kiểm tra.' } });
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: { code: 'INVALID_JSON', message: 'Nội dung JSON không hợp lệ.' } });
  }
  if (err.type === 'entity.too.large') {
    return res.status(413).json({ error: { code: 'PAYLOAD_TOO_LARGE', message: 'Nội dung yêu cầu quá lớn.' } });
  }
  if (/Mongo(Network|ServerSelection|TopologyClosed)/.test(err.name)) {
    return res.status(503).json({ error: { code: 'DATABASE_UNAVAILABLE', message: 'Không kết nối được MongoDB. Kiểm tra MongoDB Server.' } });
  }
  console.error('API error:', err.name, err.message);
  return res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Có lỗi máy chủ. Vui lòng thử lại.' } });
}
