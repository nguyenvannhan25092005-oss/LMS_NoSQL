
import { Router } from 'express';

export function createModule1Router(db) {
    const router = Router();
    const students = db.collection('students');

    // API thêm sinh viên
    router.post('/module1/students', async (req, res, next) => {
        try {
            const { student_id, full_name, class_name, email } = req.body ?? {};

            // Kiểm tra dữ liệu bắt buộc
            if (
                typeof student_id !== 'string' ||
                typeof full_name !== 'string' ||
                !student_id.trim() ||
                !full_name.trim()
            ) {
                return res.status(400).json({
                    error: {
                        code: 'VALIDATION_ERROR',
                        message: 'Mã sinh viên và họ tên không được để trống.'
                    }
                });
            }

            const id = student_id.trim().toUpperCase();

            // Kiểm tra trùng mã sinh viên
            const existing = await students.findOne({ student_id: id });

            if (existing) {
                return res.status(409).json({
                    error: {
                        code: 'DUPLICATE_STUDENT',
                        message: 'Mã sinh viên đã tồn tại.'
                    }
                });
            }

            // Chuẩn bị document MongoDB
            const student = {
                student_id: id,
                full_name: full_name.trim(),
                class_name: typeof class_name === 'string'
                    ? class_name.trim()
                    : '',
                email: typeof email === 'string'
                    ? email.trim()
                    : '',
                grades: []
            };

            // Lưu sinh viên vào MongoDB
            await students.insertOne(student);

            return res.status(201).json({
                message: 'Thêm sinh viên thành công.',
                data: student
            });

        } catch (error) {
            // MongoDB unique index cũng bảo vệ khi có yêu cầu đồng thời
            if (error.code === 11000) {
                return res.status(409).json({
                    error: {
                        code: 'DUPLICATE_STUDENT',
                        message: 'Mã sinh viên đã tồn tại.'
                    }
                });
            }

            next(error);
        }
    });

    router.put('/module1/students/:id', async (req, res, next) => {
        try {
            const studentId = req.params.id.trim().toUpperCase();
            const { full_name, class_name, email } = req.body ?? {};

            // Kiểm tra dữ liệu đầu vào
            if (
                typeof full_name !== 'string' ||
                !full_name.trim() ||
                typeof class_name !== 'string' ||
                typeof email !== 'string'
            ) {
                return res.status(400).json({
                    error: {
                        code: 'VALIDATION_ERROR',
                        message: 'Thông tin sinh viên không hợp lệ.'
                    }
                });
            }

            // Chỉ cập nhật thông tin hồ sơ, không thay đổi điểm
            const result = await db.collection('students').findOneAndUpdate(
                { student_id: studentId },
                {
                    $set: {
                        full_name: full_name.trim(),
                        class_name: class_name.trim(),
                        email: email.trim()
                    }
                },
                { returnDocument: 'after' }
            );

            if (!result) {
                return res.status(404).json({
                    error: {
                        code: 'STUDENT_NOT_FOUND',
                        message: 'Không tìm thấy sinh viên.'
                    }
                });
            }

            return res.json({
                message: 'Cập nhật sinh viên thành công.',
                data: result
            });
        } catch (error) {
            next(error);
        }
    });

    // API lấy thông tin chi tiết sinh viên
    router.get('/module1/students/:id', async (req, res, next) => {
        try {
            const studentId = req.params.id.trim().toUpperCase();

            const student = await students.findOne(
                { student_id: studentId },
                {
                    projection: {
                        _id: 0,
                        student_id: 1,
                        full_name: 1,
                        class_name: 1,
                        email: 1
                    }
                }
            );

            if (!student) {
                return res.status(404).json({
                    error: {
                        code: 'STUDENT_NOT_FOUND',
                        message: 'Không tìm thấy sinh viên.'
                    }
                });
            }

            return res.json({
                data: student
            });
        } catch (error) {
            next(error);
        }
    });

    return router;
}
